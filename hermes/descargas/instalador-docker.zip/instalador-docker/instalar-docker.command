#!/usr/bin/env bash
# SolarPunk MX - Instalador (Mac). Doble clic para ejecutar.
cd "$(dirname "$0")" || exit 1
chmod +x ./instalar-docker.sh 2>/dev/null
exec ./instalar-docker.sh
