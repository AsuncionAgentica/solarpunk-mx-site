#!/usr/bin/env bash
# ============================================================
#  SolarPunk MX - ABRIR LA INTERFAZ DE TU VPS
#  Corre ESTO EN TU COMPUTADORA (no en el servidor).
#  Levanta un tunel SSH y abre la interfaz en tu navegador.
#
#  Uso:
#     bash abrir-interfaz.sh
#     bash abrir-interfaz.sh 203.0.113.10      (si no llenaste config.txt)
# ============================================================
set -uo pipefail

AQUI="$(cd "$(dirname "$0")" && pwd)"

# Leer config.txt si existe
HOST=""; USUARIO="root"; PUERTO_SSH="22"; PUERTO_WEB="8787"
if [ -f "$AQUI/config.txt" ]; then
  # shellcheck disable=SC1090
  . "$AQUI/config.txt"
  HOST="${VPS_HOST:-}"; USUARIO="${VPS_USER:-root}"
  PUERTO_SSH="${SSH_PORT:-22}"; PUERTO_WEB="${WEB_PORT:-8787}"
fi

# Argumento manda sobre el archivo
[ $# -ge 1 ] && HOST="$1"

if [ -z "$HOST" ] || [ "$HOST" = "IP_DE_TU_SERVIDOR" ]; then
  printf 'Falta la IP de tu servidor.\n\n'
  printf 'Dos formas de darla:\n'
  printf '  1) Edita config.txt y ponla en VPS_HOST=\n'
  printf '  2) Corre: bash abrir-interfaz.sh TU_IP\n\n'
  exit 1
fi

printf '\nServidor: %s@%s (SSH %s)\n' "$USUARIO" "$HOST" "$PUERTO_SSH"
printf 'La interfaz quedara en: http://127.0.0.1:%s\n' "$PUERTO_WEB"
printf '\nTe va a pedir la contrasena o la llave del servidor.\n'
printf 'Deja esta ventana abierta mientras uses el agente.\n'
printf 'Para cerrar el tunel: Ctrl + C\n\n'

# Abrir el navegador con un pequeno retraso, mientras el tunel levanta
( sleep 3
  if command -v xdg-open >/dev/null 2>&1; then xdg-open "http://127.0.0.1:$PUERTO_WEB" >/dev/null 2>&1 &
  elif command -v open >/dev/null 2>&1; then open "http://127.0.0.1:$PUERTO_WEB" >/dev/null 2>&1 &
  else printf 'Abre tu navegador en http://127.0.0.1:%s\n' "$PUERTO_WEB"
  fi ) &

# El tunel: puerto local -> puerto del servidor, ambos en loopback
exec ssh -N -o ExitOnForwardFailure=yes \
     -L "127.0.0.1:$PUERTO_WEB:127.0.0.1:$PUERTO_WEB" \
     -p "$PUERTO_SSH" "$USUARIO@$HOST"
