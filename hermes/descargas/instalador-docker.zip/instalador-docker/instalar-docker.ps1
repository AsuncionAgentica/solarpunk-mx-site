# ==============================================================
#  SolarPunk MX - Hermes en tu computadora (Windows)
#
#  Deja tres cosas listas, en este orden:
#    1. Docker            (lo instala si falta; incluye WSL2 si hace falta)
#    2. El agente Hermes  (dentro de un contenedor seguro, panel en 9119)
#    3. Hermes Desktop    (la aplicacion nativa, conectada a tu agente)
#
#  El usuario solo escribe su contrasena de administrador una vez.
#  No copia comandos, no busca nada en internet, no reinicia a mano.
#
#  Arquitectura:
#    - LOCAL (esta ruta) -> Docker + Hermes Desktop
#    - VPS               -> interfaz web + panel (entrega aparte)
#
#  DOS REGLAS QUE NO SE ROMPEN:
#
#  1) NUNCA montar $env:USERPROFILE\.hermes en el contenedor.
#     La imagen hace chown de las carpetas que escribe (skills, sessions,
#     memories, cache...). Montar el HERMES_HOME real deja el perfil con
#     dueno 10000 y rompe el Hermes nativo que ya viva ahi: el proceso
#     deja de poder hacer stat() y se autobloquea.
#     => Este instalador usa SIEMPRE un volumen Docker dedicado.
#
#  2) NUNCA usar --insecure para saltar el login.
#     Desde el hardening de junio 2026 ese flag es NO-OP: un bind a 0.0.0.0
#     sin proveedor de auth hace que el proceso se autotermine.
#     => Se configura basic-auth y el puerto del host solo se abre en
#        127.0.0.1, asi que nadie de la red puede alcanzarlo.
# ==============================================================

$ErrorActionPreference = "Continue"
$ProgressPreference    = "SilentlyContinue"

# -- ajustes ---------------------------------------------------
$Contenedor   = if ($env:HERMES_CONTAINER) { $env:HERMES_CONTAINER } else { "hermes" }
$Imagen       = if ($env:HERMES_IMAGEN) { $env:HERMES_IMAGEN } else { "nousresearch/hermes-agent:latest" }
$PuertoDash   = if ($env:HERMES_DASH_PORT) { $env:HERMES_DASH_PORT } else { "9119" }
$Volumen      = if ($env:HERMES_VOLUMEN) { $env:HERMES_VOLUMEN } else { "hermes-data" }
$UsuarioPanel = if ($env:HERMES_PANEL_USER) { $env:HERMES_PANEL_USER } else { "solarpunk" }
$EsperaDocker = if ($env:HERMES_ESPERA) { [int]$env:HERMES_ESPERA } else { 600 }
$UrlDesktop   = "https://hermes-assets.nousresearch.com/Hermes-Setup.exe"
$Simular      = ($env:SOLARPUNK_SIMULAR -eq "1")
$Continuar    = ($args -contains "-Continuar")
$NoDesktop    = ($env:HERMES_SIN_DESKTOP -eq "1")

# -- donde guardo el avance ------------------------------------
# $env:LOCALAPPDATA siempre existe en Windows; el respaldo evita que un
# entorno raro (servicio, cuenta de sistema) rompa el script antes de empezar.
$BaseDatos  = if ($env:LOCALAPPDATA) { $env:LOCALAPPDATA } else { $env:APPDATA }
if (-not $BaseDatos) { $BaseDatos = Join-Path $env:USERPROFILE "AppData\Local" }
$Carpeta    = Join-Path $BaseDatos "SolarPunk"
$ArchivoEst = Join-Path $Carpeta "estado.json"
$ArchivoLog = Join-Path $Carpeta "instalacion.log"
$ArchivoCred = Join-Path $Carpeta "panel-credentials.txt"
$MarcaRunOnce = "SolarPunkContinuar"
New-Item -ItemType Directory -Force -Path $Carpeta | Out-Null

# -- como se ve en pantalla ------------------------------------
function Escribir($m) {
  try { "$(Get-Date -Format 'HH:mm:ss')  $m" | Out-File -Append -Encoding utf8 $ArchivoLog } catch {}
}
function Ok($m)    { Write-Host "  [OK] $m"  -ForegroundColor Green;  Escribir "OK  $m" }
function Mal($m)   { Write-Host "  [X]  $m"  -ForegroundColor Red;    Escribir "ERR $m" }
function Dato($m)  { Write-Host "  ...  $m"  -ForegroundColor Cyan;   Escribir "    $m" }
function Aviso($m) { Write-Host "  [!]  $m"  -ForegroundColor Yellow; Escribir "AVI $m" }
function Paso($m)  { Write-Host "`n$m"       -ForegroundColor White;  Escribir "==  $m" }
function Pausar   { if (-not $Simular) { Read-Host "`nPresiona Enter para cerrar" | Out-Null } }
function Abort($m) {
  Mal $m
  Write-Host ""
  Write-Host "  Guarda una foto de esta ventana y mandasela a tu instructor." -ForegroundColor Yellow
  Write-Host "  El detalle tecnico quedo en:" -ForegroundColor Yellow
  Write-Host "  $ArchivoLog" -ForegroundColor Yellow
  Pausar
  exit 1
}

# -- estado ----------------------------------------------------
function LeerEstado {
  if (Test-Path $ArchivoEst) {
    try { return Get-Content $ArchivoEst -Raw | ConvertFrom-Json } catch {}
  }
  return [pscustomobject]@{ fase = "inicio" }
}
function GuardarEstado($fase, $extra = @{}) {
  $obj = @{ fase = $fase }
  foreach ($k in $extra.Keys) { $obj[$k] = $extra[$k] }
  $obj | ConvertTo-Json | Out-File -Encoding utf8 $ArchivoEst
}
function HayComando($n) { return [bool](Get-Command $n -ErrorAction SilentlyContinue) }

# -- administrador ---------------------------------------------
function EsAdmin {
  if ($Simular) { return $true }
  try {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    $p  = New-Object Security.Principal.WindowsPrincipal($id)
    return $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
  } catch { return $false }
}
function Elevar {
  $script = $PSCommandPath
  Dato "Windows me va a pedir permiso de administrador. Acepta para continuar."
  try {
    if ($Continuar) {
      Start-Process -FilePath (Get-Process -Id $PID).Path `
        -ArgumentList "-NoProfile","-ExecutionPolicy","Bypass","-File","`"$script`"","-Continuar" `
        -Verb RunAs | Out-Null
    } else {
      Start-Process -FilePath (Get-Process -Id $PID).Path `
        -ArgumentList "-NoProfile","-ExecutionPolicy","Bypass","-File","`"$script`"" `
        -Verb RunAs | Out-Null
    }
  } catch {
    Abort "No se otorgo el permiso de administrador, y lo necesito para instalar Docker."
  }
  exit 0
}

# -- continuar tras el reinicio --------------------------------
function ProgramarContinuacion {
  if ($Simular) { Escribir "simulado: RunOnce registrado"; return }
  $cmd = "powershell -NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`" -Continuar"
  try {
    Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce" `
      -Name $MarcaRunOnce -Value $cmd -Force
    Ok "Deje el trabajo programado: al volver a entrar, sigue solo"
  } catch {
    Aviso "No pude programar la continuacion automatica."
    Aviso "Si al reiniciar no continua, vuelve a hacer doble clic en instalar-docker.bat"
  }
}
function QuitarContinuacion {
  if ($Simular) { return }
  try {
    Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce" `
      -Name $MarcaRunOnce -ErrorAction SilentlyContinue
  } catch {}
}

# -- que tiene ya la maquina -----------------------------------
function WslListo {
  if (HayComando "wsl") {
    try {
      $salida = (& wsl --status 2>&1 | Out-String)
      if ($salida -match "Default Version:\s*2" -or $salida -match "Version predeterminada:\s*2") { return $true }
      if ($LASTEXITCODE -eq 0 -and
          $salida -notmatch "no esta instalado|no está instalado|not installed|no se reconoce|not recognized") {
        return $true
      }
    } catch {}
  }
  try {
    $a = Get-WindowsOptionalFeature -Online -FeatureName Microsoft-Windows-Subsystem-Linux -ErrorAction Stop
    $b = Get-WindowsOptionalFeature -Online -FeatureName VirtualMachinePlatform -ErrorAction Stop
    return ($a.State -eq "Enabled" -and $b.State -eq "Enabled")
  } catch {}
  return (HayComando "wsl")
}

function VirtualizacionActiva {
  try {
    $cs = Get-CimInstance Win32_ComputerSystem -ErrorAction Stop
    return [bool]$cs.HypervisorPresent
  } catch { return $true }
}

function InstalarWsl {
  if (HayComando "wsl") {
    Dato "Instalando el soporte de Linux de Windows (WSL2)..."
    & wsl --install --no-distribution 2>&1 | ForEach-Object { Write-Host "       $_" -ForegroundColor DarkGray }
    if ($LASTEXITCODE -eq 0) { return $true }
    Aviso "El instalador automatico no funciono. Uso el metodo alternativo..."
  }
  if (HayComando "dism") {
    Dato "Habilitando 'Windows Subsystem for Linux'..."
    & dism.exe /online /enable-feature /featurename:Microsoft-Windows-Subsystem-Linux /all /norestart 2>&1 | Out-Null
    Dato "Habilitando 'Virtual Machine Platform'..."
    & dism.exe /online /enable-feature /featurename:VirtualMachinePlatform /all /norestart 2>&1 | Out-Null
    return $true
  }
  return $false
}

function DockerInstalado {
  if (HayComando "docker") { return $true }
  foreach ($r in @("$env:ProgramFiles\Docker\Docker\Docker Desktop.exe",
                   "${env:ProgramFiles(x86)}\Docker\Docker\Docker Desktop.exe")) {
    if ($r -and (Test-Path $r)) { return $true }
  }
  return $false
}

function InstalarDocker {
  if (HayComando "winget") {
    Dato "Instalando Docker Desktop. Tarda varios minutos; no cierres esta ventana."
    & winget install --id Docker.DockerDesktop --exact `
        --accept-source-agreements --accept-package-agreements --silent 2>&1 |
      ForEach-Object { Write-Host "       $_" -ForegroundColor DarkGray }
    if ($LASTEXITCODE -eq 0) { return $true }
    Aviso "El instalador automatico no termino bien. Pruebo el instalador oficial..."
  }
  $exe = Join-Path $env:TEMP "DockerDesktopInstaller.exe"
  $url = "https://desktop.docker.com/win/main/amd64/Docker%20Desktop%20Installer.exe"
  Dato "Descargando Docker (son varios cientos de MB, ten paciencia)..."
  try { Invoke-WebRequest -Uri $url -OutFile $exe -UseBasicParsing }
  catch { Abort "No pude descargar Docker. Revisa tu conexion a internet." }
  Dato "Instalando Docker. Si Windows pide permiso, acepta."
  try {
    $p = Start-Process -FilePath $exe `
      -ArgumentList "install","--quiet","--accept-license" -Wait -PassThru -Verb RunAs
    if ($p.ExitCode -eq 0) { return $true }
    Abort "La instalacion de Docker no termino bien (codigo $($p.ExitCode))."
  } catch { Abort "No se pudo instalar Docker." }
}

function AceptarLicenciaDocker {
  if ($Simular) { return }
  $cfg = Join-Path $env:APPDATA "Docker"
  New-Item -ItemType Directory -Force -Path $cfg | Out-Null
  $archivo = Join-Path $cfg "settings-store.json"
  try {
    $j = if (Test-Path $archivo) { Get-Content $archivo -Raw | ConvertFrom-Json } else { [pscustomobject]@{} }
    $j | Add-Member -NotePropertyName "AcceptLicenseTerms"  -NotePropertyValue $true -Force
    $j | Add-Member -NotePropertyName "LicenseTermsVersion" -NotePropertyValue 2     -Force
    $j | Add-Member -NotePropertyName "AutoStart"           -NotePropertyValue $true -Force
    $j | ConvertTo-Json | Out-File -Encoding utf8 $archivo
  } catch { Aviso "No pude dejar la licencia aceptada por adelantado (no es grave)." }
}

function ArrancarDocker {
  if ($Simular) { return }
  $dd = "$env:ProgramFiles\Docker\Docker\Docker Desktop.exe"
  if (Test-Path $dd) { Dato "Abriendo Docker..."; Start-Process $dd | Out-Null }
  else { Aviso "No encontre Docker Desktop para abrirlo. Abrelo desde el menu Inicio." }
}

function MotorVivo {
  try { & docker info *> $null; return ($LASTEXITCODE -eq 0) } catch { return $false }
}

function RefrescarRutas {
  $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" +
              [System.Environment]::GetEnvironmentVariable("Path","User")
}

# -- el agente dentro del contenedor ---------------------------
function ContenedorExiste {
  return ((& docker ps -a --format "{{.Names}}") -contains $Contenedor)
}

function MontaPerfilReal {
  # Detecto el montaje peligroso de instalaciones anteriores. Montar el
  # HERMES_HOME real deja el perfil con dueno 10000 y rompe el Hermes nativo
  # que ya viva ahi (el proceso deja de poder hacer stat() y se autobloquea).
  try {
    $m = & docker inspect -f '{{range .Mounts}}{{.Source}}{{"\n"}}{{end}}' $Contenedor 2>$null | Out-String
    return ($m -match "\.hermes")
  } catch { return $false }
}

function GenerarPassword {
  # Legible y sin simbolos raros (se dicta facil). No se imprime en pantalla.
  $abc = "abcdefghijkmnopqrstuvwxyz23456789"
  $rnd = New-Object System.Security.Cryptography.RNGCryptoServiceProvider
  $bytes = New-Object byte[] 20
  $rnd.GetBytes($bytes)
  $sb = New-Object System.Text.StringBuilder
  foreach ($b in $bytes) { [void]$sb.Append($abc[$b % $abc.Length]) }
  return $sb.ToString()
}

function PrepararCredenciales {
  if (Test-Path $ArchivoCred) {
    $linea = Get-Content $ArchivoCred | Where-Object { $_ -match "^CONTRASENA=" }
    if ($linea) {
      Ok "Reutilizando la contrasena del panel que ya tenias"
      return ($linea -replace "^CONTRASENA=","")
    }
  }
  $pw = GenerarPassword
  $txt = @(
    "PANEL=http://127.0.0.1:$PuertoDash",
    "USUARIO=$UsuarioPanel",
    "CONTRASENA=$pw"
  ) -join "`r`n"
  try {
    $txt | Out-File -Encoding utf8 -NoNewline $ArchivoCred
    # Equivalente a chmod 600: solo el usuario actual puede leerla.
    $acl = Get-Acl $ArchivoCred
    $acl.SetAccessRuleProtection($true, $false)
    $me = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
    $rule = New-Object System.Security.AccessControl.FileSystemAccessRule($me,"FullControl","Allow")
    $acl.AddAccessRule($rule)
    Set-Acl -Path $ArchivoCred -AclObject $acl
  } catch { Aviso "No pude restringir el archivo de contrasena; guardalo tu." }
  Ok "Contrasena del panel generada (guardada, no se muestra aqui)"
  return $pw
}

function CrearContenedor($clave) {
  if ($Simular) { Escribir "simulado: contenedor"; return $true }

  # Volumen dedicado: lo crea Docker y se queda con el dueno correcto.
  # NUNCA apuntamos a $env:USERPROFILE\.hermes — ver nota al inicio.
  & docker volume inspect $Volumen *> $null
  if ($LASTEXITCODE -ne 0) {
    & docker volume create $Volumen *> $null
    if ($LASTEXITCODE -ne 0) { Abort "No pude crear el volumen de datos de Hermes." }
  }

  # El panel escucha en 0.0.0.0 DENTRO del contenedor (si no, el reenvio de
  # puerto de Docker no llega) y se protege con basic-auth. El puerto del host
  # solo se publica en 127.0.0.1, asi que nadie de la red lo alcanza.
  # --insecure ya NO sirve: es NO-OP desde el hardening de junio 2026.
  & docker run -d --name $Contenedor `
      --restart unless-stopped `
      -p "127.0.0.1:${PuertoDash}:9119" `
      -v "${Volumen}:/opt/data" `
      -e "HERMES_UID=10000" -e "HERMES_GID=10000" `
      -e "HERMES_DASHBOARD_BASIC_AUTH_USERNAME=$UsuarioPanel" `
      -e "HERMES_DASHBOARD_BASIC_AUTH_PASSWORD=$clave" `
      $Imagen serve --host 0.0.0.0 --port 9119 *> $null
  return ($LASTEXITCODE -eq 0)
}

function EsperarPanel {
  # Espero a que el panel responda de verdad antes de tocar Desktop.
  $url = "http://127.0.0.1:${PuertoDash}/api/status"
  $t = 0
  while ($t -lt 180) {
    try {
      $r = Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec 5
      if ($r.StatusCode -eq 200 -and $r.Content) { return $r.Content }
    } catch {}
    Start-Sleep -Seconds 3; $t += 3
    Write-Host "." -NoNewline
  }
  return $null
}

function ProbarLogin($clave) {
  # Un panel que responde pero rechaza la contrasena correcta deja al alumno
  # sin poder entrar, y desde fuera se ve igual que un panel sano.
  $url = "http://127.0.0.1:${PuertoDash}/auth/password-login"
  $body = @{ provider = "basic"; username = $UsuarioPanel; password = $clave } | ConvertTo-Json
  try {
    $r = Invoke-WebRequest -Uri $url -Method POST -Body $body -ContentType "application/json" `
         -UseBasicParsing -TimeoutSec 10
    return ($r.StatusCode -eq 200)
  } catch { return $false }
}

# -- Hermes Desktop (la aplicacion nativa) ---------------------
function DesktopInstalado {
  if ($Simular) { return (Test-Path (Join-Path $Carpeta "desktop.instalado")) }
  foreach ($r in @(
      (Join-Path $env:LOCALAPPDATA "Programs\Hermes\Hermes.exe"),
      (Join-Path $env:LOCALAPPDATA "Hermes\Hermes.exe"),
      (Join-Path $env:ProgramFiles "Hermes\Hermes.exe"))) {
    if ($r -and (Test-Path $r)) { return $true }
  }
  $menu = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\Hermes.lnk"
  return (Test-Path $menu)
}

function InstalarDesktop {
  $exe = Join-Path $env:TEMP "Hermes-Setup.exe"
  Dato "Descargando Hermes Desktop (la aplicacion)..."
  try { Invoke-WebRequest -Uri $UrlDesktop -OutFile $exe -UseBasicParsing }
  catch { Abort "No pude descargar Hermes Desktop. Revisa tu conexion a internet." }
  if ((Get-Item $exe).Length -lt 1MB) { Abort "El archivo de Hermes Desktop llego incompleto." }

  # Instalacion silenciosa de NSIS: sin ventanas, sin preguntas.
  Dato "Instalando Hermes Desktop. Puede tardar un par de minutos..."
  try {
    $p = Start-Process -FilePath $exe -ArgumentList "/S" -Wait -PassThru
    if ($p.ExitCode -ne 0) {
      Aviso "La instalacion silenciosa no termino bien. Lo abro de forma visible..."
      Start-Process -FilePath $exe -Wait
    }
  } catch {
    Dato "Abriendo el instalador de Hermes Desktop; completa lo que muestre."
    Start-Process -FilePath $exe -Wait
  }
  if ($Simular) { New-Item -ItemType File -Force -Path (Join-Path $Carpeta "desktop.instalado") | Out-Null }
  return $true
}

function RutaDesktop {
  foreach ($r in @(
      (Join-Path $env:LOCALAPPDATA "Programs\Hermes\Hermes.exe"),
      (Join-Path $env:LOCALAPPDATA "Hermes\Hermes.exe"),
      (Join-Path $env:ProgramFiles "Hermes\Hermes.exe"))) {
    if ($r -and (Test-Path $r)) { return $r }
  }
  return $null
}

function CrearAccesoDirecto {
  # El acceso directo es lo que el alumno va a usar todos los dias. Arranca
  # el contenedor si estaba detenido y luego abre la app.
  $exe = RutaDesktop
  $destino = $exe

  if (-not $exe) {
    $lnkMenu = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\Hermes.lnk"
    if (-not (Test-Path $lnkMenu)) {
      Aviso "No encontre Hermes.exe para crear el acceso directo."
      return $false
    }
    $destino = $lnkMenu
  }

  # Lanzador: enciende el agente y abre la app. Vive junto a las credenciales
  # para que el acceso directo tenga un solo destino estable.
  $lanzador = Join-Path $Carpeta "Abrir Hermes Desktop.cmd"
  $lineas = @(
    "@echo off",
    "title Hermes Desktop",
    "docker start $Contenedor >nul 2>&1",
    "start `"`" `"$destino`"",
    "exit"
  )
  try {
    $lineas -join "`r`n" | Out-File -Encoding ascii $lanzador
  } catch {
    Aviso "No pude crear el lanzador: $($_.Exception.Message)"
    return $false
  }

  $icono = if ($exe) { "$exe,0" } else { "$env:SystemRoot\System32\shell32.dll,13" }
  $hecho = $false

  # 1) Acceso directo en el Escritorio
  try {
    $wsh = New-Object -ComObject WScript.Shell
    $lnk = Join-Path ([Environment]::GetFolderPath("Desktop")) "Hermes Desktop.lnk"
    $s = $wsh.CreateShortcut($lnk)
    $s.TargetPath       = $lanzador
    $s.WorkingDirectory = $Carpeta
    $s.IconLocation     = $icono
    $s.Description      = "Abre Hermes Desktop con tu agente"
    $s.Save()
    Ok "Acceso directo creado en el Escritorio"
    $hecho = $true
  } catch { Aviso "No pude crear el acceso del Escritorio: $($_.Exception.Message)" }

  # 2) Y en el menu Inicio, para que aparezca al buscar 'Hermes'
  try {
    $wsh2 = New-Object -ComObject WScript.Shell
    $menuDir = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs"
    $lnk2 = Join-Path $menuDir "Hermes Desktop (SolarPunk).lnk"
    $s2 = $wsh2.CreateShortcut($lnk2)
    $s2.TargetPath       = $lanzador
    $s2.WorkingDirectory = $Carpeta
    $s2.IconLocation     = $icono
    $s2.Description      = "Abre Hermes Desktop con tu agente"
    $s2.Save()
    Ok "Acceso directo creado en el menu Inicio"
    $hecho = $true
  } catch { Escribir "no pude crear el acceso del menu Inicio: $($_.Exception.Message)" }

  return $hecho
}

function AbrirDesktop {
  if ($Simular) { return }
  foreach ($c in @(
      (Join-Path $env:LOCALAPPDATA "Programs\Hermes\Hermes.exe"),
      (Join-Path $env:LOCALAPPDATA "Hermes\Hermes.exe"),
      (Join-Path $env:ProgramFiles "Hermes\Hermes.exe"))) {
    if ($c -and (Test-Path $c)) { Dato "Abriendo Hermes Desktop..."; Start-Process $c | Out-Null; return }
  }
  $menu = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\Hermes.lnk"
  if (Test-Path $menu) { Dato "Abriendo Hermes Desktop..."; Start-Process $menu | Out-Null }
}

# ==============================================================
#  ARRANQUE
# ==============================================================
Write-Host "=============================================="
Write-Host "  SolarPunk MX - Hermes en tu computadora"
Write-Host "=============================================="

$est = LeerEstado
if ($Continuar) {
  Write-Host ""
  Write-Host "  Continuando la instalacion donde se quedo..." -ForegroundColor Cyan
}

if (-not (EsAdmin)) { Elevar; exit 0 }

if (-not $Simular -and -not (VirtualizacionActiva) -and -not (WslListo)) {
  Write-Host ""
  Aviso "La virtualizacion de tu computadora esta apagada y no puedo encenderla yo."
  Write-Host "  Es un ajuste de la BIOS que solo se cambia al encender la maquina." -ForegroundColor Yellow
  Write-Host "  Manda esta pantalla a tu instructor y te guiamos paso a paso." -ForegroundColor Yellow
  Pausar
  exit 1
}

# == PASO 1 - WSL2 =============================================
Paso "1. Preparando el soporte de Linux de Windows"

if (WslListo) {
  Ok "Tu Windows ya lo tiene"
} else {
  Aviso "Tu Windows necesita un componente (WSL2). Lo instalo por ti."
  if (-not (InstalarWsl)) {
    Abort "No pude instalar WSL2 automaticamente. Manda esta pantalla a tu instructor."
  }
  Ok "WSL2 instalado"

  GuardarEstado "wsl_pendiente_reinicio"
  ProgramarContinuacion

  Write-Host ""
  Write-Host "=============================================="
  Write-Host "  HACE FALTA REINICIAR TU COMPUTADORA"
  Write-Host "=============================================="
  Write-Host "  Es normal: Windows lo pide una sola vez."
  Write-Host ""
  Write-Host "  Guarda lo que tengas abierto." -ForegroundColor Yellow
  Write-Host "  Al volver a entrar, la instalacion sigue SOLA." -ForegroundColor Green
  Write-Host "=============================================="
  if (-not $Simular) {
    Write-Host ""
    Write-Host "  Reinicio en 1 minuto. Si prefieres hacerlo despues," -ForegroundColor Yellow
    Write-Host "  cierra esta ventana y reinicia cuando quieras:" -ForegroundColor Green
    Write-Host "  la instalacion continuara igual." -ForegroundColor Green
    & shutdown.exe /r /t 60 /c "SolarPunk: reiniciando para continuar la instalacion" 2>&1 | Out-Null
    Write-Host ""
    Write-Host "  (Para cancelar el reinicio automatico, escribe:  shutdown /a )" -ForegroundColor DarkGray
  } else { Escribir "simulado: aqui reiniciaria" }
  Pausar
  exit 0
}

# == PASO 2 - Docker ===========================================
Paso "2. Preparando Docker"

if (DockerInstalado) {
  Ok "Docker ya esta instalado"
  RefrescarRutas
} else {
  if (-not (InstalarDocker)) { Abort "No pude instalar Docker." }
  Ok "Docker instalado"
  RefrescarRutas
}

AceptarLicenciaDocker

# == PASO 3 - Encender el motor ================================
Paso "3. Encendiendo Docker"

if (MotorVivo) {
  Ok "Docker ya esta encendido"
} else {
  ArrancarDocker
  Dato "Esperando a que Docker este listo (la primera vez tarda unos minutos)..."
  $t = 0
  while (-not (MotorVivo)) {
    Start-Sleep -Seconds 5; $t += 5
    if ($t -ge $EsperaDocker) {
      Abort "Docker no respondio. Abre Docker Desktop, espera a que diga 'Running' y vuelve a ejecutar este instalador."
    }
    Write-Host "." -NoNewline
  }
  Write-Host ""
  Ok "Docker esta encendido"
}

# == PASO 4 - El agente ========================================
Paso "4. Preparando tu agente"

if (-not (HayComando "docker")) { RefrescarRutas }

& docker image inspect $Imagen *> $null
if ($LASTEXITCODE -ne 0) {
  Dato "Descargando Hermes (una sola vez, puede tardar)..."
  & docker pull $Imagen
  if ($LASTEXITCODE -ne 0) { Abort "No pude descargar Hermes. Revisa tu conexion a internet." }
}
Ok "Hermes listo"

# == PASO 5 - Contenedor + credenciales ========================
Paso "5. Creando tu espacio seguro"

$clave = PrepararCredenciales
if (-not $clave) { Abort "No pude preparar la contrasena del panel." }

if (ContenedorExiste) {
  if (MontaPerfilReal) {
    Aviso "Tu agente anterior usaba una configuracion que puede danar tu perfil."
    Dato "Lo reemplazo por uno seguro (tus datos del curso no se tocan)."
    & docker rm -f $Contenedor *> $null
    if (-not (CrearContenedor $clave)) { Abort "No pude crear tu agente. Prueba: docker logs $Contenedor" }
    Ok "Agente creado de nuevo, seguro"
  } else {
    Ok "Tu espacio ya existe"
    & docker start $Contenedor *> $null
    Ok "Encendido"
  }
} else {
  if (-not (CrearContenedor $clave)) { Abort "No pude crear tu espacio. Prueba: docker logs $Contenedor" }
  Ok "Espacio creado"
}

# == PASO 6 - Verificacion real ================================
Paso "6. Verificando que tu agente responda"

Dato "Esperando a que conteste..."
$estado = EsperarPanel
Write-Host ""

if (-not $estado) {
  Mal "Tu agente no contesto. Ultimas lineas del registro:"
  & docker logs --tail 15 $Contenedor 2>&1 | ForEach-Object { Write-Host "      $_" }
  Abort "No continuo a la instalacion de la app hasta que el agente responda."
}

if ($estado -match '"auth_required"\s*:\s*true') {
  Ok "Tu agente responde y esta protegido con contrasena"
} else {
  Aviso "Tu agente responde pero no reporta proteccion de acceso."
  Dato "Revisa con: docker logs $Contenedor"
}

if (ProbarLogin $clave) {
  Ok "La contrasena del panel funciona"
} else {
  Mal "La contrasena del panel no fue aceptada."
  & docker logs --tail 12 $Contenedor 2>&1 | ForEach-Object { Write-Host "      $_" }
  Abort "No sigo hasta que el panel acepte tu contrasena."
}

# == PASO 7 - Hermes Desktop ===================================
Paso "7. Instalando Hermes Desktop (la aplicacion)"

if ($NoDesktop) {
  Aviso "Omitido por configuracion."
} elseif (DesktopInstalado) {
  Ok "Hermes Desktop ya esta instalado"
} else {
  if (-not (InstalarDesktop)) { Abort "No pude instalar Hermes Desktop." }
  Ok "Hermes Desktop instalado"
}

# == PASO 8 - Acceso directo ===================================
Paso "8. Creando el acceso directo de Hermes Desktop"

if ($NoDesktop) {
  Aviso "Omitido por configuracion."
} elseif (CrearAccesoDirecto) {
  Ok "Listo: usa el acceso directo 'Hermes Desktop'"
} else {
  Aviso "No pude crear el acceso directo; abre la app y configura la conexion a mano."
}

GuardarEstado "completo"
QuitarContinuacion

# == FIN =======================================================
Write-Host ""
Write-Host "=============================================="
Write-Host "  LISTO! TU AGENTE YA VIVE EN TU COMPUTADORA"
Write-Host "=============================================="
Write-Host "  Usuario del panel: $UsuarioPanel"
Write-Host "  Contrasena       : en $ArchivoCred"
Write-Host "                     (no se muestra aqui a proposito)"
Write-Host ""
Write-Host "  Abre 'Hermes Desktop' desde el Escritorio."
Write-Host ""
Write-Host "  Detalle tecnico, por si te sirve:"
Write-Host "    Tu agente : contenedor '$Contenedor' (imagen $Imagen)"
Write-Host "    Panel     : http://127.0.0.1:$PuertoDash (solo en tu equipo)"
Write-Host "    Tus datos : volumen Docker '$Volumen' (no toca tu .hermes)"
Write-Host ""
Write-Host "  Todo se queda en tu equipo. Nada sale de aqui"
Write-Host "  salvo lo que tu decidas."
Write-Host ""
Write-Host "  SIGUIENTE PASO:"
Write-Host "  Vuelve a la pagina del curso y llena el cuestionario."
Write-Host "  Con tus respuestas te preparo tus agentes."
Write-Host "=============================================="
AbrirDesktop
Pausar
