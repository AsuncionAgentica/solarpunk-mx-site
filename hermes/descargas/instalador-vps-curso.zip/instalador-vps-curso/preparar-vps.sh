#!/usr/bin/env bash
# ============================================================
#  SolarPunk MX - PREPARADOR DEL VPS  (se corre EN el VPS, como root)
#  Deja el agente Hermes disponible por la interfaz web en 127.0.0.1.
#  Idempotente: se puede correr varias veces sin romper nada.
#
#  Uso:
#     scp preparar-vps.sh root@IP:/root/
#     ssh root@IP 'bash /root/preparar-vps.sh'
# ============================================================
set -uo pipefail
log(){ printf '\n=== %s ===\n' "$*"; }

log "1/6 Hermes presente?"
if ! command -v hermes >/dev/null 2>&1 && [ ! -x "$HOME/.local/bin/hermes" ]; then
  echo "Hermes no esta; lo instalo (10-20 min)..."
  apt-get update -qq && apt-get install -y -qq libatomic1 curl git
  curl -fsSL https://hermes-agent.nousresearch.com/install.sh | bash
fi
HERMES="$(command -v hermes || echo "$HOME/.local/bin/hermes")"
"$HERMES" --version || true

log "2/6 Herramientas base (git)"
command -v git >/dev/null 2>&1 || { apt-get update -qq && apt-get install -y -qq git; }

log "3/6 Interfaz web (hermes-webui)"
WEBUI_DIR="/root/hermes-webui"
if [ -d "$WEBUI_DIR" ]; then echo "Ya existe $WEBUI_DIR."; else
  git clone -q https://github.com/nesquena/hermes-webui.git "$WEBUI_DIR" || { echo "No pude clonar."; exit 1; }
fi

log "4/6 Servicio systemd: hermes-webui (8787, loopback)"
cat > /etc/systemd/system/hermes-webui.service <<'UNIT'
[Unit]
Description=Hermes WebUI (SolarPunk)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=root
WorkingDirectory=/root/hermes-webui
Environment=PATH=/root/.local/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
ExecStart=/usr/bin/python3 /root/hermes-webui/bootstrap.py --foreground --no-browser --host 127.0.0.1 8787
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
UNIT

log "5/6 Servicio systemd: hermes-backend (9119, loopback)"
cat > /etc/systemd/system/hermes-backend.service <<'UNIT'
[Unit]
Description=Hermes backend (serve) - SolarPunk
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=root
Environment=PATH=/root/.local/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
ExecStart=/root/.local/bin/hermes serve --host 127.0.0.1 --port 9119
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
UNIT

systemctl daemon-reload
systemctl enable --now hermes-webui.service hermes-backend.service

log "6/6 Esperando a que respondan"
for i in $(seq 1 40); do
  ss -ltn 2>/dev/null | grep -q ':8787 ' && break; sleep 3
done
systemctl is-active hermes-webui hermes-backend

log "Resumen"
echo "Interfaz web : http://127.0.0.1:8787   (dentro del VPS; el estudiante la trae por tunel)"
echo "Respaldo     : http://127.0.0.1:9119"
echo "Servicios    : systemctl status hermes-webui hermes-backend"
echo
echo "Todo en 127.0.0.1 (loopback). Nadie entra sin el tunel SSH. Listo."
