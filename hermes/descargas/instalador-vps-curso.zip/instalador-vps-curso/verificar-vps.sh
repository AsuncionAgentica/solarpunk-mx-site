#!/usr/bin/env bash
# ============================================================
#  SolarPunk MX - VERIFICADOR DEL VPS
#  Se corre desde TU maquina (instructor), contra el VPS del estudiante.
#
#  Uso:  bash verificar-vps.sh IP_DEL_VPS [USUARIO] [PUERTO_SSH] [KEY]
#  Sin KEY: usa la autenticacion por defecto (llave/agente).
# ============================================================
set -uo pipefail
HOST="${1:?uso: verificar-vps.sh HOST [USER] [SSH_PORT] [KEY]}"
USER="${2:-root}"
PORT="${3:-22}"
KEY="${4:-}"

KEYOPT=()
[ -n "$KEY" ] && KEYOPT=(-i "$KEY")

ok(){ printf '  [OK] %s\n' "$*"; }
bad(){ printf '  [!!] %s\n' "$*"; FAIL=1; }
FAIL=0

echo "VPS: $USER@$HOST:$PORT"
SSH=(ssh -p "$PORT" -o ConnectTimeout=10 -o StrictHostKeyChecking=accept-new "${KEYOPT[@]}" "$USER@$HOST")

echo
echo "1) Servicios systemd"
for svc in hermes-webui hermes-backend; do
  ST="$("${SSH[@]}" "systemctl is-active $svc 2>/dev/null" 2>/dev/null)"
  EN="$("${SSH[@]}" "systemctl is-enabled $svc 2>/dev/null" 2>/dev/null)"
  if [ "$ST" = "active" ]; then ok "$svc activo (enabled=$EN)"; else bad "$svc NO activo ($ST) — corre preparar-vps.sh"; fi
done

echo
echo "2) Interfaces en loopback"
PORTS="$("${SSH[@]}" 'ss -ltn' 2>/dev/null)"
for p in 8787 9119; do
  if echo "$PORTS" | grep -q "127.0.0.1:$p "; then ok "puerto $p escuchando en 127.0.0.1"; else bad "puerto $p NO escucha"; fi
done
if echo "$PORTS" | grep -Eq '0\.0\.0\.0:(8787|9119) '; then bad "ADVERTENCIA: 8787/9119 expuesto en 0.0.0.0 (debe ser solo loopback)"; fi

echo
echo "3) Hermes instalado"
V="$("${SSH[@]}" 'export PATH="$HOME/.local/bin:$PATH"; hermes --version 2>/dev/null | head -1' 2>/dev/null)"
if echo "$V" | grep -qi hermes; then ok "Hermes: $V"; else bad "Hermes no responde"; fi

echo
echo "4) Tunel de prueba -> HTTP"
ssh -f -N -p "$PORT" -o ExitOnForwardFailure=yes -o StrictHostKeyChecking=accept-new "${KEYOPT[@]}" \
    -L 18787:127.0.0.1:8787 "$USER@$HOST" 2>/dev/null
sleep 2
CODE="$(curl -s -m 10 -o /dev/null -w '%{http_code}' http://127.0.0.1:18787/ 2>/dev/null || echo 000)"
if [ "$CODE" = "200" ]; then ok "HTTP 200 a traves del tunel"; else bad "HTTP $CODE (revisa la webui)"; fi
pkill -f "18787:127.0.0.1:8787" 2>/dev/null || true

echo
if [ "$FAIL" = "0" ]; then
  echo "RESULTADO: LISTO PARA ENTREGAR."
else
  echo "RESULTADO: REVISAR los puntos marcados [!!] antes de entregar."
  exit 1
fi
