#!/usr/bin/env bash
# ============================================================
#  SolarPunk MX — Hermes en tu computadora (Linux / macOS)
#
#  Deja tres cosas listas, en este orden:
#    1. Docker            (lo instala si falta)
#    2. El agente Hermes  (en un contenedor, puerto 9119 en loopback)
#    3. Hermes Desktop    (la aplicación nativa, conectada a tu agente)
#
#  Arquitectura:
#    - LOCAL (esta ruta) -> Docker + Hermes Desktop
#    - VPS               -> interfaz web + panel (entrega aparte)
#
#  DOS REGLAS QUE NO SE ROMPEN:
#
#  1) NUNCA montar ~/.hermes en el contenedor.
#     La imagen hace chown de las carpetas que escribe (skills, sessions,
#     memories, cache...). Montar el HERMES_HOME real de la máquina deja el
#     perfil con dueño 10000 y rompe el Hermes nativo que ya viva ahí:
#     el proceso deja de poder hacer stat() y se autobloquea.
#     => Este instalador usa SIEMPRE un volumen Docker dedicado.
#
#  2) NUNCA usar --insecure para saltar el login.
#     Desde el hardening de junio 2026 ese flag es NO-OP: un bind a 0.0.0.0
#     sin proveedor de auth hace que el proceso se autotermine.
#     => Se configura basic-auth y el puerto del host solo se abre en
#        127.0.0.1, así que nadie fuera del equipo puede alcanzarlo.
#
#  Uso:  bash instalar-docker.sh   (o doble clic en Mac)
# ============================================================
set -uo pipefail

CONTENEDOR="${HERMES_CONTAINER:-hermes}"
IMAGEN="${HERMES_IMAGEN:-nousresearch/hermes-agent:latest}"
PUERTO_DASH="${HERMES_DASH_PORT:-9119}"
VOLUMEN="${HERMES_VOLUMEN:-hermes-data}"
ESPERA_MOTOR="${HERMES_ESPERA:-300}"   # segundos máximos de espera
URL_DESKTOP_MAC="https://hermes-assets.nousresearch.com/Hermes-Setup.dmg"
URL_INSTALADOR="https://hermes-agent.nousresearch.com/install.sh"
USUARIO_PANEL="${HERMES_PANEL_USER:-solarpunk}"

ok(){    printf '  \033[32m✓\033[0m %s\n' "$*"; }
mal(){   printf '  \033[31m✗\033[0m %s\n' "$*"; }
dato(){  printf '  \033[36m•\033[0m %s\n' "$*"; }
paso(){  printf '\n\033[1m%s\033[0m\n' "$*"; }
aviso(){ printf '  \033[33m!\033[0m %s\n' "$*"; }
abort(){ printf '\n\033[31m%s\033[0m\n' "$*"; printf '\nPresiona Enter para cerrar…'; read -r _ || true; exit 1; }
fin(){   printf '\nPresiona Enter para cerrar…'; read -r _ || true; }

# ── utilidades ──────────────────────────────────────────────
SUDO=""
SUDO_LISTO=""
preparar_sudo(){
  [ -n "$SUDO_LISTO" ] && return          # ya lo preparé en este paso
  if [ "$(id -u)" -eq 0 ]; then SUDO=""; SUDO_LISTO=1; return; fi
  if command -v sudo >/dev/null 2>&1; then
    SUDO="sudo"
    if [ -z "${_AVISE_SUDO:-}" ]; then
      aviso "Necesito permiso de administrador. Te pedirá tu contraseña."
      dato "No se ve al escribirla; es normal."
      _AVISE_SUDO=1
    fi
  else
    abort "Necesito permisos de administrador y no encontré 'sudo' en tu sistema."
  fi
  SUDO_LISTO=1
}

motor_vivo(){ docker info >/dev/null 2>&1; }

# Genera una contraseña legible sin símbolos raros (se dicta fácil).
# Va a un archivo local con permisos 600; NUNCA se imprime en pantalla.
generar_password(){
  local base
  base="$(LC_ALL=C tr -dc 'a-z0-9' </dev/urandom 2>/dev/null | head -c 20)"
  if [ -z "$base" ]; then
    base="$(date +%s | shasum -a 256 2>/dev/null | cut -c1-20)"
  fi
  printf '%s' "$base"
}

directorio_secreto(){
  # Hermes Desktop no existe todavía en este punto; guardo junto a la app.
  if [ "$(uname -s)" = "Darwin" ]; then
    printf '%s' "$HOME/Library/Application Support/SolarPunk"
  else
    printf '%s' "${XDG_CONFIG_HOME:-$HOME/.config}/solarpunk"
  fi
}

SO="$(uname -s)"
echo "=============================================="
echo "  SolarPunk MX — Hermes en tu computadora"
echo "=============================================="

# ══ PASO 1 · ¿Hay Docker? ═══════════════════════════════════
paso "1. Revisando si Docker está instalado"

if command -v docker >/dev/null 2>&1; then
  ok "Docker ya está instalado ($(docker --version 2>/dev/null | cut -d, -f1))"
else
  aviso "Docker no está en tu computadora. Lo voy a instalar por ti."
  preparar_sudo

  if [ "$SO" = "Darwin" ]; then
    # ── macOS: descargar e instalar Docker Desktop ──
    ARQ="$(uname -m)"
    if [ "$ARQ" = "arm64" ]; then
      URL="https://desktop.docker.com/mac/main/arm64/Docker.dmg"
    else
      URL="https://desktop.docker.com/mac/main/amd64/Docker.dmg"
    fi
    DMG="/tmp/Docker-$$.dmg"
    dato "Descargando Docker (≈590 MB, puede tardar unos minutos)…"
    curl -fL --progress-bar -o "$DMG" "$URL" || abort "No pude descargar Docker. Revisa tu conexión a internet."

    dato "Instalando Docker…"
    MONTAJE="$(hdiutil attach "$DMG" -nobrowse -quiet | tail -1 | awk '{print $NF}')" \
      || abort "No pude abrir el instalador de Docker."
    [ -d "$MONTAJE/Docker.app" ] || abort "El instalador de Docker no trae la aplicación esperada."
    $SUDO rm -rf /Applications/Docker.app 2>/dev/null
    $SUDO cp -R "$MONTAJE/Docker.app" /Applications/ || { hdiutil detach "$MONTAJE" -quiet 2>/dev/null; abort "No pude copiar Docker a Aplicaciones."; }
    hdiutil detach "$MONTAJE" -quiet 2>/dev/null
    rm -f "$DMG"
    ok "Docker instalado en /Applications"

  elif [ "$SO" = "Linux" ]; then
    # ── Linux: instalador oficial de Docker ──
    GUION="/tmp/get-docker-$$.sh"
    dato "Descargando el instalador oficial de Docker…"
    curl -fsSL -o "$GUION" https://get.docker.com \
      || abort "No pude descargar el instalador de Docker. Revisa tu conexión."

    # Verifico que sea el guion oficial antes de ejecutarlo.
    if ! head -1 "$GUION" | grep -q '^#!/bin/sh' \
       || ! grep -q 'install_docker_packages\|docker.com' "$GUION"; then
      rm -f "$GUION"
      abort "El archivo descargado no parece el instalador oficial. Me detengo por seguridad."
    fi
    ok "Instalador oficial verificado"

    dato "Instalando Docker (te pedirá tu contraseña)…"
    if [ -n "$SUDO" ]; then
      $SUDO sh "$GUION" || { rm -f "$GUION"; abort "La instalación de Docker no terminó bien."; }
    else
      sh "$GUION" || { rm -f "$GUION"; abort "La instalación de Docker no terminó bien."; }
    fi
    rm -f "$GUION"

    if [ -n "$SUDO" ] && command -v groups >/dev/null 2>&1 && ! groups | grep -qw docker; then
      $SUDO usermod -aG docker "$USER" 2>/dev/null && \
        dato "Te agregué al grupo 'docker' (aplica al reiniciar sesión)."
    fi
    ok "Docker instalado"
  else
    abort "No reconozco tu sistema ($SO). Escríbele a tu instructor."
  fi
fi

# ══ PASO 2 · ¿El motor está encendido? ══════════════════════
paso "2. Encendiendo el motor de Docker"

if motor_vivo; then
  ok "El motor ya está encendido"
else
  dato "El motor está apagado. Lo enciendo…"

  if [ "$SO" = "Darwin" ]; then
    open -a Docker 2>/dev/null || dato "Abre Docker desde Aplicaciones si no arranca solo."
  else
    preparar_sudo
    if command -v systemctl >/dev/null 2>&1; then
      $SUDO systemctl enable --now docker >/dev/null 2>&1
    elif command -v service >/dev/null 2>&1; then
      $SUDO service docker start >/dev/null 2>&1
    fi
    sleep 2
    if ! motor_vivo && [ -f /var/run/docker.sock ]; then
      $SUDO chmod 666 /var/run/docker.sock 2>/dev/null
    fi
  fi

  dato "Esperando a que Docker esté listo…"
  T=0
  until motor_vivo; do
    sleep 3; T=$((T+3))
    if [ "$T" -ge "$ESPERA_MOTOR" ]; then
      abort "Docker no respondió después de $((ESPERA_MOTOR/60)) minutos. Abre Docker, espera a que diga 'Running' y vuelve a intentar."
    fi
    printf '.'
  done
  printf '\n'
  ok "El motor está encendido ($(docker info --format '{{.ServerVersion}}' 2>/dev/null))"
fi

# ══ PASO 3 · La imagen de Hermes ════════════════════════════
paso "3. Preparando tu agente"

if docker image inspect "$IMAGEN" >/dev/null 2>&1; then
  ok "Hermes ya está descargado"
else
  dato "Descargando Hermes (una sola vez, puede tardar)…"
  docker pull "$IMAGEN" || abort "No pude descargar Hermes. Revisa tu conexión a internet."
  ok "Hermes descargado"
fi

# ══ PASO 4 · Tu espacio + credenciales del panel ════════════
paso "4. Creando tu espacio seguro"

# El volumen dedicado lo crea Docker la primera vez y se queda con el dueño
# correcto. Nunca apuntamos a $HOME/.hermes.
if docker volume inspect "$VOLUMEN" >/dev/null 2>&1; then
  ok "Tu espacio ya existe"
else
  docker volume create "$VOLUMEN" >/dev/null \
    || abort "No pude crear el volumen de datos de Hermes."
  ok "Espacio creado"
fi

SECRETOS="$(directorio_secreto)"
mkdir -p "$SECRETOS" 2>/dev/null
chmod 700 "$SECRETOS" 2>/dev/null
ARCHIVO_CRED="$SECRETOS/panel-credentials.txt"

if [ -s "$ARCHIVO_CRED" ]; then
  CLAVE_PANEL="$(sed -n 's/^CONTRASENA=//p' "$ARCHIVO_CRED" | head -1)"
fi
if [ -z "${CLAVE_PANEL:-}" ]; then
  CLAVE_PANEL="$(generar_password)"
  [ -n "$CLAVE_PANEL" ] || abort "No pude generar la contraseña del panel."
  ( umask 077; printf 'PANEL=http://127.0.0.1:%s\nUSUARIO=%s\nCONTRASENA=%s\n' \
      "$PUERTO_DASH" "$USUARIO_PANEL" "$CLAVE_PANEL" > "$ARCHIVO_CRED" )
  chmod 600 "$ARCHIVO_CRED" 2>/dev/null
  ok "Contraseña del panel generada (guardada en tu equipo, no se muestra aquí)"
else
  ok "Reutilizando la contraseña del panel que ya tenías"
fi

# ══ PASO 5 · El contenedor ══════════════════════════════════
paso "5. Encendiendo tu agente"

if docker ps -a --format '{{.Names}}' 2>/dev/null | grep -qx "$CONTENEDOR"; then
  ok "Tu agente ya existe"
  # Si el contenedor viejo se creó con la configuración insegura (--insecure,
  # montaje de $HOME/.hermes), lo reemplazo en vez de reutilizarlo.
  MONTA_VIEJO="$(docker inspect -f '{{range .Mounts}}{{.Source}}{{"\n"}}{{end}}' "$CONTENEDOR" 2>/dev/null)"
  case "$MONTA_VIEJO" in
    *".hermes"*)
      aviso "Tu agente anterior usaba una configuración que puede dañar tu perfil."
      dato "Lo reemplazo por uno seguro (tus datos del curso no se tocan)."
      docker rm -f "$CONTENEDOR" >/dev/null 2>&1
      RECREAR=1
      ;;
    *) RECREAR=0 ;;
  esac
  if [ "${RECREAR:-0}" = "0" ]; then
    docker start "$CONTENEDOR" >/dev/null 2>&1 && ok "Encendido"
  fi
fi

if ! docker ps -a --format '{{.Names}}' 2>/dev/null | grep -qx "$CONTENEDOR"; then
  # El panel escucha en 0.0.0.0 DENTRO del contenedor (si no, el reenvío de
  # puerto de Docker no llega) y se protege con basic-auth. El puerto del
  # host solo se publica en 127.0.0.1, así que nadie de la red lo alcanza.
  docker run -d --name "$CONTENEDOR" \
    --restart unless-stopped \
    -p "127.0.0.1:${PUERTO_DASH}:9119" \
    -v "${VOLUMEN}:/opt/data" \
    -e "HERMES_UID=10000" -e "HERMES_GID=10000" \
    -e "HERMES_DASHBOARD_BASIC_AUTH_USERNAME=${USUARIO_PANEL}" \
    -e "HERMES_DASHBOARD_BASIC_AUTH_PASSWORD=${CLAVE_PANEL}" \
    "$IMAGEN" serve --host 0.0.0.0 --port 9119 >/dev/null \
    || abort "No pude crear tu agente. Prueba: docker logs $CONTENEDOR"
  ok "Agente creado"
fi

# ══ PASO 6 · Verificación real (no confío en el exit code) ═══
paso "6. Verificando que tu agente responda"

dato "Esperando a que conteste…"
T=0; ESTADO=""
while [ "$T" -lt 180 ]; do
  ESTADO="$(curl -fsS -m 5 "http://127.0.0.1:${PUERTO_DASH}/api/status" 2>/dev/null)"
  [ -n "$ESTADO" ] && break
  sleep 3; T=$((T+3)); printf '.'
done
printf '\n'

if [ -z "$ESTADO" ]; then
  mal "Tu agente no contestó. Últimas líneas del registro:"
  docker logs --tail 15 "$CONTENEDOR" 2>&1 | sed 's/^/      /'
  abort "No continúo a la instalación de la app hasta que el agente responda."
fi

# Verifico que el candado de acceso esté puesto de verdad.
if printf '%s' "$ESTADO" | grep -q '"auth_required"[[:space:]]*:[[:space:]]*true'; then
  ok "Tu agente responde y está protegido con contraseña"
else
  aviso "Tu agente responde pero no reporta protección de acceso."
  dato "Revisa con: docker logs $CONTENEDOR"
fi

# Verifico que el login funcione de verdad. Un panel que responde pero rechaza
# la contraseña correcta deja al alumno sin poder entrar, y desde fuera se ve
# igual que un panel sano.
if curl -fsS -m 10 -X POST -H 'Content-Type: application/json' \
     -d "$(printf '{"provider":"basic","username":"%s","password":"%s"}' "$USUARIO_PANEL" "$CLAVE_PANEL")" \
     -o /dev/null "http://127.0.0.1:${PUERTO_DASH}/auth/password-login" 2>/dev/null; then
  ok "La contraseña del panel funciona"
else
  mal "La contraseña del panel no fue aceptada."
  dato "Últimas líneas del registro:"
  docker logs --tail 12 "$CONTENEDOR" 2>&1 | sed 's/^/      /'
  abort "No sigo hasta que el panel acepte tu contraseña."
fi

# ══ PASO 7 · Hermes Desktop ═════════════════════════════════
paso "7. Instalando Hermes Desktop (la aplicación)"

if [ "${HERMES_SIN_DESKTOP:-0}" = "1" ]; then
  aviso "Omitido por configuración."
elif [ "$SO" = "Darwin" ]; then
  if [ -d "/Applications/Hermes.app" ]; then
    ok "Hermes Desktop ya está instalado"
  else
    DMG="/tmp/Hermes-Setup-$$.dmg"
    dato "Descargando Hermes Desktop (la aplicación)…"
    curl -fL --progress-bar -o "$DMG" "$URL_DESKTOP_MAC" \
      || abort "No pude descargar Hermes Desktop. Revisa tu conexión a internet."

    dato "Instalando Hermes Desktop…"
    MONTAJE="$(hdiutil attach "$DMG" -nobrowse -quiet | tail -1 | awk '{print $NF}')" \
      || abort "No pude abrir el instalador de Hermes Desktop."
    if [ -d "$MONTAJE/Hermes.app" ]; then
      $SUDO rm -rf /Applications/Hermes.app 2>/dev/null
      $SUDO cp -R "$MONTAJE/Hermes.app" /Applications/ \
        || { hdiutil detach "$MONTAJE" -quiet 2>/dev/null; abort "No pude copiar Hermes a Aplicaciones."; }
      hdiutil detach "$MONTAJE" -quiet 2>/dev/null
      rm -f "$DMG"
      ok "Hermes Desktop instalado"
    else
      hdiutil detach "$MONTAJE" -quiet 2>/dev/null
      rm -f "$DMG"
      aviso "El instalador de Hermes Desktop se abrió; completa lo que muestre en pantalla."
    fi
  fi
else
  # Linux: Hermes se instala por terminal y la app se abre con el comando desktop.
  if command -v hermes >/dev/null 2>&1; then
    ok "Hermes ya está instalado en el sistema"
  else
    dato "Descargando Hermes para tu sistema…"
    GUION="/tmp/instalar-hermes-$$.sh"
    curl -fsSL -o "$GUION" "$URL_INSTALADOR" \
      || abort "No pude descargar Hermes. Revisa tu conexión a internet."
    dato "Instalando Hermes (puede tardar unos minutos)…"
    bash "$GUION" || { rm -f "$GUION"; abort "La instalación de Hermes no terminó bien."; }
    rm -f "$GUION"
    ok "Hermes instalado"
  fi
fi

# ══ PASO 8 · Unir la app con tu agente ══════════════════════
paso "8. Conectando la aplicación con tu agente"

if [ "${HERMES_SIN_DESKTOP:-0}" = "1" ]; then
  aviso "Omitido por configuración."
elif [ "$SO" = "Darwin" ]; then
  # La app se configura desde su propia pantalla de Gateways; solo digo qué poner.
  ok "Abre Hermes Desktop y usa estos datos (están en tu archivo de credenciales):"
  dato "Dirección : http://127.0.0.1:${PUERTO_DASH}"
  dato "Usuario   : ${USUARIO_PANEL}"
  dato "Contraseña: la del archivo ${ARCHIVO_CRED}"
else
  if command -v hermes >/dev/null 2>&1; then
    # Desktop en Linux se lanza desde el propio Hermes y hereda esta variable,
    # así que la conexión queda resuelta sin escribir archivos a mano.
    ARCHIVO_ENTORNO="${XDG_CONFIG_HOME:-$HOME/.config}/solarpunk/entorno-desktop.sh"
    mkdir -p "$(dirname "$ARCHIVO_ENTORNO")" 2>/dev/null
    ( umask 077; cat > "$ARCHIVO_ENTORNO" <<EOF
# Generado por el instalador SolarPunk. Apunta Hermes Desktop a tu agente.
export HERMES_DESKTOP_REMOTE_URL="http://127.0.0.1:${PUERTO_DASH}"
export HERMES_DESKTOP_PANEL_USER="${USUARIO_PANEL}"
export HERMES_PANEL_CREDENTIALS="${ARCHIVO_CRED}"
EOF
    )
    chmod 600 "$ARCHIVO_ENTORNO" 2>/dev/null
    ok "Conexión preparada para Hermes Desktop"
    dato "Arranca la app con:  source ${ARCHIVO_ENTORNO} && hermes desktop"
  else
    aviso "No encontré el comando 'hermes'; configura la conexión desde la app."
  fi
fi

echo
echo "=============================================="
echo "  ¡LISTO! TU AGENTE YA VIVE EN TU COMPUTADORA"
echo "=============================================="
echo "  Usuario del panel: ${USUARIO_PANEL}"
echo "  Contraseña       : en ${ARCHIVO_CRED}"
echo "                     (no se muestra aquí a propósito)"
echo
if [ "$SO" = "Darwin" ]; then
  echo "  Abre Hermes Desktop desde Aplicaciones."
else
  echo "  Abre Hermes Desktop con:  source ${ARCHIVO_ENTORNO:-/dev/null} && hermes desktop"
fi
echo
echo "  Detalle técnico, por si te sirve:"
echo "    Tu agente : contenedor '$CONTENEDOR' (imagen ${IMAGEN})"
echo "    Panel     : http://127.0.0.1:${PUERTO_DASH} (solo en tu equipo)"
echo "    Tus datos : volumen Docker '${VOLUMEN}' (no toca tu ~/.hermes)"
echo
echo "  Todo se queda en tu equipo. Nada sale de aquí"
echo "  salvo lo que tú decidas."
echo
echo "  SIGUIENTE PASO:"
echo "  Vuelve a la página del curso y llena el cuestionario."
echo "  Con tus respuestas te preparo tus agentes."
echo "=============================================="
fin
