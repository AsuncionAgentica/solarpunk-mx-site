# ============================================================
#  SolarPunk MX - Lanzador de conexion (Windows 11)   v4
#  Un clic: abre el tunel seguro a tu VPS y tu agente.
#  No guarda contrasenas. El VPS NO puede alcanzar tu PC.
#
#  Si algo falla, este script NO se cierra solo: te muestra el
#  error y deja un archivo 'conexion-log.txt' junto a el.
# ============================================================
$ErrorActionPreference = "Continue"   # v3: 'Stop' + stderr de comandos nativos
                                      # hacia que la ventana se cerrara de golpe.
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not $here) { $here = (Get-Location).Path }
$log = Join-Path $here "conexion-log.txt"
$script:LogLines = @()

function Say([string]$m) {
  Write-Host $m
  $script:LogLines += ("{0}  {1}" -f (Get-Date -Format "HH:mm:ss"), $m)
}
function FlushLog { try { $script:LogLines | Set-Content -Path $log -Encoding UTF8 } catch { } }
function Pausa([string]$m) {
  if ($m) { Say ""; Say $m }
  FlushLog
  Say ""
  Say "Presiona Enter para cerrar esta ventana..."
  try { [void](Read-Host) } catch { Start-Sleep -Seconds 20 }
}
trap {
  Say ""
  Say "ERROR INESPERADO: $($_.Exception.Message)"
  Pausa "Se guardo el diagnostico en: $log"
  exit 1
}

function TcpOpen([string]$h, [int]$p) {
  try {
    $c = New-Object System.Net.Sockets.TcpClient
    $r = $c.BeginConnect($h, $p, $null, $null)
    if (-not $r.AsyncWaitHandle.WaitOne(700)) { $c.Close(); return $false }
    $ok = $c.Connected; $c.Close(); return $ok
  } catch { return $false }
}
function KeySinContrasena([string]$k) {
  if (-not (Test-Path $k)) { return $false }
  if (Select-String -Path $k -Pattern "bcrypt" -Quiet) { return $false }  # cifrada: pediria passphrase
  return $true
}

Say "==============================================="
Say "  SolarPunk MX - conexion segura a tu agente   (v3)"
Say "==============================================="
Say "Carpeta: $here"

# --- config.txt ---
$cfg = Join-Path $here "config.txt"
if (-not (Test-Path $cfg)) { $cfg = Join-Path (Split-Path -Parent $here) "config.txt" }
if (-not (Test-Path $cfg)) { Pausa "ERROR: falta config.txt junto a este script."; exit 1 }

$conf = @{}
Get-Content $cfg | ForEach-Object {
  $line = $_.Trim()
  if ($line -eq "" -or $line.StartsWith("#")) { return }
  $i = $line.IndexOf("=")
  if ($i -gt 0) { $conf[$line.Substring(0,$i).Trim()] = $line.Substring($i+1).Trim() }
}
$VpsHost  = $conf["VPS_HOST"]
$VpsUser  = if ($conf["VPS_USER"]) { $conf["VPS_USER"] } else { "root" }
$SshPort  = if ($conf["SSH_PORT"]) { $conf["SSH_PORT"] } else { "22" }
$WebPort  = if ($conf["WEB_PORT"]) { $conf["WEB_PORT"] } else { "8787" }
$DashPort = if ($conf["DASH_PORT"]) { $conf["DASH_PORT"] } else { "9119" }

if (-not $VpsHost -or $VpsHost -eq "TU_IP_O_HOST") {
  Say ""
  Say "Escribe la IP de tu servidor."
  Say "(Es la que te dio tu instructor o aparece en tu panel de Contabo.)"
  $VpsHost = (Read-Host "IP del servidor").Trim()
  if (-not $VpsHost) { Pausa "No escribiste ninguna IP."; exit 1 }
  try { Add-Content -Path $cfg -Value "VPS_HOST=$VpsHost" } catch { }
}
Say "Servidor: $VpsUser@$VpsHost (SSH $SshPort) -> web local $WebPort"

if (-not (Get-Command ssh -ErrorAction SilentlyContinue)) {
  Pausa "No encontre 'ssh'. Instala OpenSSH Client: Configuracion > Aplicaciones > Caracteristicas opcionales > Agregar > Cliente OpenSSH."; exit 1 }
if (-not (Get-Command ssh-keygen -ErrorAction SilentlyContinue)) { Pausa "No encontre 'ssh-keygen'."; exit 1 }

$sshDir = Join-Path $env:USERPROFILE ".ssh"
$key    = Join-Path $sshDir "solarpunk_vps_ed25519"

$common = @("-o","StrictHostKeyChecking=accept-new","-o","ForwardAgent=no",
            "-o","ServerAliveInterval=30","-o","ServerAliveCountMax=3",
            "-o","ExitOnForwardFailure=yes","-p",$SshPort)

function NuevaLlave {
  if (-not (Test-Path $sshDir)) { New-Item -ItemType Directory -Force $sshDir | Out-Null }
  Say "Generando tu llave de acceso (una sola vez)..."
  Remove-Item $key,"$key.pub" -ErrorAction SilentlyContinue
  # Intento 1: la forma que funciona en la mayoria de los builds.
  & ssh-keygen -q -t ed25519 -f $key -N '""' -C "solarpunk-$env:COMPUTERNAME" 2>&1 | Out-Null
  if (-not (KeySinContrasena $key)) {
    # Intento 2: cadena vacia nativa.
    Remove-Item $key,"$key.pub" -ErrorAction SilentlyContinue
    & ssh-keygen -q -t ed25519 -f $key -N "" -C "solarpunk-$env:COMPUTERNAME" 2>&1 | Out-Null
  }
  if (-not (KeySinContrasena $key)) {
    # Intento 3: guiado, el estudiante solo presiona Enter dos veces.
    Remove-Item $key,"$key.pub" -ErrorAction SilentlyContinue
    Say "Ultimo intento: cuando pregunte, presiona Enter DOS veces sin escribir nada."
    & ssh-keygen -t ed25519 -f $key -C "solarpunk-$env:COMPUTERNAME"
  }
  if (-not (KeySinContrasena $key)) { Pausa "No se pudo crear la llave. Manda conexion-log.txt a Humberto."; exit 1 }
  Say "Llave lista."
}

if (-not (Test-Path $key)) { NuevaLlave }
elseif (-not (KeySinContrasena $key)) {
  $bak = "$key.revisar-$(Get-Date -Format yyyyMMdd-HHmmss)"
  Say "La llave guardada quedo con contrasena (por el error de la version anterior)."
  Say "Se guarda una copia en: $bak  y se genera una nueva."
  Move-Item $key $bak -Force
  Remove-Item "$key.pub" -ErrorAction SilentlyContinue
  NuevaLlave
}

# --- Enrolar la llave (solo la primera vez) ---
$probe = & ssh @common "-oBatchMode=yes" "-oConnectTimeout=7" "-i" $key "$VpsUser@$VpsHost" "exit 0" 2>&1
$probeOk = ($LASTEXITCODE -eq 0)
if (-not $probeOk) {
  $detalle = (($probe | Where-Object { "$_".Trim() -ne "" } | Select-Object -First 3) -join " | ")
  if ($detalle) { Say "ssh respondio: $detalle" }
}
if (-not $probeOk) {
  Say ""
  Say "Primera conexion a este servidor. Te pedira la contrasena UNA vez."
  Say "(Es la contrasena actual de root de tu VPS. Solo sirve para instalar tu llave.)"
  Say ""
  $pub = (Get-Content "$key.pub" -Raw).Trim()
  $remote = @'
umask 077; mkdir -p ~/.ssh; touch ~/.ssh/authorized_keys; chmod 600 ~/.ssh/authorized_keys; grep -qxF '__PUB__' ~/.ssh/authorized_keys || echo '__PUB__' >> ~/.ssh/authorized_keys
'@
  $remote = $remote.Replace("__PUB__", $pub).Replace("`r`n", "`n").Replace("`r", "`n").Trim()
  & ssh @common "$VpsUser@$VpsHost" $remote
  if ($LASTEXITCODE -ne 0) {
    Pausa "No pude autenticar con esa contrasena. Si no la sabes, hay que resetearla en el panel de Contabo (Servers & Hosting > ... > Reset credentials)."; exit 1
  }
  $probe2 = & ssh @common "-oBatchMode=yes" "-oConnectTimeout=7" "-i" $key "$VpsUser@$VpsHost" "exit 0" 2>&1
  if ($LASTEXITCODE -ne 0) {
    $detalle = (($probe2 | Where-Object { "$_".Trim() -ne "" } | Select-Object -First 3) -join " | ")
    Pausa ("La llave no quedo instalada. ssh dijo: " + $detalle); exit 1
  }
  Say "Listo: tu llave quedo instalada. Ya no volvera a pedir contrasena."
}

# --- Abrir el tunel ---
$fwd = @("-L","${WebPort}:127.0.0.1:${WebPort}")
if ($DashPort -ne $WebPort) {
  if (TcpOpen "127.0.0.1" ([int]$DashPort)) {
    Say "Aviso: el puerto local $DashPort ya esta ocupado; se omite el respaldo."
  } else {
    $fwd += @("-L","${DashPort}:127.0.0.1:${DashPort}")
  }
}
$tun = @("-N") + $common + @("-i",$key) + $fwd + @("$VpsUser@$VpsHost")

# IMPORTANTE (v4): -ArgumentList une el arreglo con espacios y NO cita los elementos.
# Con un nombre de usuario que lleva espacio ("Hiram Vidales") la ruta de la llave se
# partia en dos y ssh veia 'C:\Users\Hiram' como archivo de identidad.
# Se cita explicitamente todo argumento que contenga espacios o comillas.
function ArgStr([string[]]$a) {
  ($a | ForEach-Object { if ($_ -match '[\s"]') { '"' + ($_ -replace '"','\"') + '"' } else { $_ } }) -join " "
}
$tunLine = ArgStr $tun

Say ""
Say "Abriendo tunel seguro al VPS..."
$errFile = Join-Path $here "tunel-error.txt"
Remove-Item $errFile -ErrorAction SilentlyContinue
Start-Process -FilePath "ssh" -ArgumentList $tunLine -WindowStyle Minimized -RedirectStandardError $errFile

$listo = $false
for ($i=0; $i -lt 25; $i++) {
  if (TcpOpen "127.0.0.1" ([int]$WebPort)) { $listo = $true; break }
  Start-Sleep -Milliseconds 700
}

$httpOk = $false
if ($listo) {
  try {
    $r = Invoke-WebRequest -Uri "http://127.0.0.1:$WebPort" -UseBasicParsing -TimeoutSec 8
    $httpOk = ($r.StatusCode -ge 200 -and $r.StatusCode -lt 400)
  } catch { $httpOk = $false }
}

if ($httpOk) { Start-Process "http://127.0.0.1:$WebPort" }

Say "==============================================="
if ($httpOk) {
  Say "  TU AGENTE ESTA ABIERTO EN EL NAVEGADOR"
} elseif ($listo) {
  Say "  El tunel responde, pero el agente aun no contesta."
  Say "  Abre o recarga: http://127.0.0.1:$WebPort"
} else {
  Say "  El tunel NO se abrio."
  if (Test-Path $errFile) { foreach ($l in (Get-Content $errFile | Select-Object -First 4)) { Say "  ssh: $l" } }
  Say "  Manda conexion-log.txt + tunel-error.txt a tu instructor (abajo esta la linea exacta que se ejecuto)."
}
Say "  Interfaz web : http://127.0.0.1:$WebPort"
Say "  Respaldo     : http://127.0.0.1:$DashPort"
if ($httpOk) {
  Say "  La ventana minimizada 'SolarPunk' es el puente seguro."
  Say "  Dejala abierta mientras trabajas; cierrala para desconectarte."
} else {
  Say "  Linea de diagnostico (mandala junto con los logs):"
  Say "  ssh $tunLine"
}
Say "==============================================="
Pausa "Ya puedes cerrar esta ventana."
