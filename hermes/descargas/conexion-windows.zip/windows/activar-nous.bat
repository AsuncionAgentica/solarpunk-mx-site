@echo off
REM ============================================================
REM  SolarPunk MX - Activar tu cuenta de Nous   (Windows 11)
REM  PASO 2 del onboarding: conecta TU cuenta de Nous.
REM  Doble clic aqui. No pide contrasena del servidor.
REM  Corre en TU servidor; tu cuenta queda ahi, no en tu PC.
REM ============================================================
setlocal
set "AQUI=%~dp0"
cd /d "%AQUI%"
if not exist "activar-nous.ps1" if exist "windows\activar-nous.ps1" cd /d "%AQUI%windows"

if not exist "activar-nous.ps1" (
  echo.
  echo No encuentro activar-nous.ps1 en esta carpeta:
  echo   %CD%
  echo Descomprime el ZIP completo y vuelve a intentar.
  echo.
  pause
  exit /b 1
)

echo.
echo  Activando tu cuenta de Nous en tu agente...
echo.

powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -LiteralPath '%CD%' -Recurse -File -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue" >nul 2>&1
powershell -NoProfile -ExecutionPolicy Bypass -File "%CD%\activar-nous.ps1"

echo.
echo  ------------------------------------------------------------
echo  Cuando termine, cierra esta ventana y usa conectar.bat.
echo  ------------------------------------------------------------
pause
endlocal
