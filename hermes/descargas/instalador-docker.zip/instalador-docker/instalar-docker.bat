@echo off
title SolarPunk MX - Hermes en tu computadora
chcp 65001 >nul 2>&1
echo ==============================================
echo   SolarPunk MX - Instalando Hermes
echo ==============================================
echo.
echo   No cierres esta ventana.
echo   Windows te pedira permiso de administrador: acepta.
echo   La primera vez tarda varios minutos.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar-docker.ps1"
set CODIGO=%ERRORLEVEL%
echo.
if not "%CODIGO%"=="0" (
  echo   La instalacion no termino bien ^(codigo %CODIGO%^).
  echo   Manda una foto de esta ventana a tu instructor.
) else (
  echo   Listo. Abre "Hermes Desktop" desde el Escritorio.
)
echo.
pause
