# Tu agente, en tu propia computadora

Este paquete deja Hermes funcionando en tu computadora dentro de un espacio
seguro. Todo tu trabajo y tus datos se quedan aquí; nada sale de tu equipo
salvo lo que tú decidas.

**El instalador hace todo solo.** Deja tres cosas listas, en este orden:

  1. **Docker** — el espacio seguro donde vive tu agente.
  2. **Tu agente Hermes** — ya funcionando dentro de ese espacio.
  3. **Hermes Desktop** — la aplicación con la que platicas con él.

Tú solo escribes tu contraseña de administrador cuando el sistema te la pida.
No copias comandos, no eliges versiones, no buscas nada en internet.

========================================================
  ELIGE TU COMPUTADORA
========================================================

  [ WINDOWS ]  ->  ve a la PARTE 1
  [ MAC ]      ->  ve a la PARTE 2


========================================================
  PARTE 1 — WINDOWS
========================================================

Windows es el que más cosas necesita, y por eso el instalador es el que más
hace solo: revisa si tu Windows tiene lo necesario, lo instala si falta, y si
Windows te pide reiniciar, **la instalación continúa sola al volver a entrar**.

--- PASO 1. Descomprime este paquete ---
  Clic derecho sobre el archivo ZIP que descargaste
  -> "Extraer todo..."
  -> "Extraer"

Se creará una carpeta. Entra en ella.

  IMPORTANTE: no ejecutes nada desde dentro del ZIP.
  Primero extrae, y trabaja dentro de la carpeta extraída.

--- PASO 2. Ejecuta el instalador ---
  Haz DOBLE CLIC en el archivo:   instalar-docker.bat

  Si aparece un aviso azul de Windows ("Windows protegió tu PC"):
     -> clic en "Más información"
     -> clic en "Ejecutar de todas formas"

  Se abrirá una ventana negra que hace todo sola.
  Windows te pedirá permiso de administrador: acepta.
  Deja que termine. La primera vez tarda varios minutos.

  ── Si te pide reiniciar la computadora ──
  Puede pasar. Es normal y solo ocurre una vez.
  Cuando reinicies y vuelvas a entrar a tu sesión, la instalación
  continúa automáticamente. No tienes que hacer nada más.

|--- PASO 3. Abre tu agente ---
  Al terminar, el instalador abre Hermes Desktop solo y deja un acceso
  directo llamado "Hermes Desktop" en tu Escritorio.
  Si no se abrió, usa ese acceso directo.

  Esa es la aplicación con la que platicas con tu agente.
  Todo corre en TU computadora.

  La primera vez que abras la app, pide la dirección y la contraseña
  de tu agente. Los dos datos están en este archivo:
     %LOCALAPPDATA%\SolarPunk\panel-credentials.txt
  El instalador te dice la ruta exacta al terminar.

--- Para usarlo otro día ---
  Haz doble clic en "Hermes Desktop" del Escritorio.
  (Ese acceso directo también enciende el agente si estaba apagado.)


========================================================
  PARTE 2 — MAC
========================================================

--- PASO 1. Descomprime este paquete ---
  Haz doble clic sobre el archivo ZIP que descargaste.
  Se creará una carpeta sin la palabra ".zip". Entra en ella.

--- PASO 2. Ejecuta el instalador ---
  Haz DOBLE CLIC en el archivo:   instalar-docker.command

  La primera vez, Mac puede decir que no puede abrirlo porque es de
  un desarrollador no identificado. Para permitirlo:
     -> clic derecho (o Control + clic) sobre "instalar-docker.command"
     -> "Abrir"
     -> en el aviso, vuelve a pulsar "Abrir"
  Solo hay que hacer esto la primera vez.

  Se abrirá una ventana de "Terminal" que hace todo sola.
  Te pedirá tu contraseña de Mac para instalar Docker: escríbela
  (no se ve mientras escribes: es normal) y presiona Enter.
  Deja que termine. La primera vez tarda varios minutos.

|--- PASO 3. Abre tu agente ---
  Al terminar, abre Hermes desde tu carpeta Aplicaciones.

  Esa es la aplicación con la que platicas con tu agente.
  Todo corre en TU computadora.

  La primera vez que abras la app, pide la dirección y la contraseña
  de tu agente. Los dos datos están en este archivo:
     ~/.config/solarpunk/panel-credentials.txt
  El instalador te dice la ruta exacta al terminar.

--- Para usarlo otro día ---
  Solo abre "Hermes" desde Aplicaciones.

--- Si al hacer doble clic se abre un editor de texto en vez de la Terminal ---
  Abre la app "Terminal" (Command + Espacio, escribe "Terminal", Enter),
  luego escribe lo siguiente cambiando "TU_CARPETA" por la carpeta donde
  descomprimiste el ZIP:

      cd ~/Descargas/TU_CARPETA
      bash instalar-docker.sh

  Y presiona Enter.


========================================================
  SI ALGO NO FUNCIONA
========================================================

| Lo que ves | Qué hacer |
|---|---|
| Te pide reiniciar | Es normal. Reinicia y la instalación sigue sola. |
| «La virtualización está apagada» | Es un ajuste de la BIOS; mándale la pantalla a tu instructor. |
| «Docker no respondió» | Abre Docker Desktop, espera a que diga "Running" y ejecuta otra vez el instalador. |
| Te pidió contraseña y no la tienes | Necesitas una cuenta de administrador en tu computadora. |
| No abre Hermes Desktop | Ábrelo desde el menú Inicio (Windows) o Aplicaciones (Mac); espera un minuto y vuelve a intentar. |
| Mac: «desarrollador no identificado» | Clic derecho sobre el archivo -> "Abrir" -> "Abrir". |
| Se cortó la descarga | Vuelve a ejecutar el instalador: retoma donde iba. |
| Nada de lo anterior | Manda a tu instructor una foto de la ventana negra. |

En Windows, el detalle técnico queda guardado en:
   %LOCALAPPDATA%\SolarPunk\instalacion.log
Ese archivo es lo que ayuda a tu instructor a resolver cualquier problema.


========================================================
  DETALLES TÉCNICOS (por si te sirven)
========================================================

- Contenedor: `hermes`
- Imagen: `nousresearch/hermes-agent:latest`
- Tus datos: volumen Docker `hermes-data` montado en `/opt/data`
- Panel: `127.0.0.1:9119` (solo en tu computadora, no se expone a la red)
- Acceso: usuario `solarpunk` + contraseña en `panel-credentials.txt`

Por qué el volumen y no una carpeta: el contenedor cambia el dueño de las
carpetas que escribe. Si se montara tu carpeta de usuario, el Hermes que ya
vive en tu equipo dejaría de poder leerla. El volumen dedicado lo evita.

Detener:  `docker stop hermes`
Arrancar: `docker start hermes`
Registro: `docker logs hermes`
