# Tu agente SolarPunk — cómo conectarte desde Windows 11

Esta guia es la version Markdown del paso a paso: la fuente unica es
`onboarding/pasos.yaml` y el paso a paso imprimible es `EMPIEZA-AQUI.txt`.

## LO QUE NECESITAS TENER A LA MANO

1. Tu computadora con Windows 11.
2. La IP de tu servidor (te la dio tu instructor o aparece
   en tu panel de Contabo).
3. La contrasena de tu servidor (te la dio tu instructor).
4. Tu cuenta de Nous Research. Si no la tienes, en el PASO 5
   te decimos donde crearla gratis.

## PASO 1 - DESCOMPRIME EL ZIP

Clic derecho sobre el archivo ZIP -> "Extraer todo..." -> "Extraer".
Se creara una carpeta. Entra en ella.

IMPORTANTE: no ejecutes los archivos de adentro del ZIP
directamente. Si lo haces, Windows cierra la ventana sola.
Primero extrae, y luego trabaja sobre la carpeta extraida.

## PASO 2 - DOBLE CLIC EN "conectar.bat"

Haz doble clic en el archivo llamado:   conectar.bat

Windows mostrara un aviso azul ("Windows protegio tu PC").
Haz clic en "Mas informacion" y luego en "Ejecutar de todas
formas". Es normal: el archivo es seguro.

NOTA: veras varios archivos parecidos. Los dos que te importan:
        conectar.bat      (PASO 2)
        activar-nous.bat  (PASO 5)

## PASO 3 - ESCRIBE LA IP DE TU SERVIDOR

La primera vez te pedira la IP de tu servidor.
Escribela y presiona Enter. (Se guarda para las proximas veces.)

## PASO 4 - ESCRIBE LA CONTRASENA (SOLO LA PRIMERA VEZ)

Despues te pedira la contrasena de tu servidor.
Escribela y presiona Enter.
NO se ve mientras escribes: es normal.

Esta contrasena se usa UNA sola vez. Despues ya no te la volvera
a pedir, porque queda instalada tu llave de acceso segura.

## PASO 5 - CONECTA TU CUENTA DE NOUS

Tu agente usa TU PROPIA cuenta de Nous Research, asi que hay que
conectarla una sola vez. Sin este paso el agente abre pero no
puede responder.

Doble clic en:   activar-nous.bat

- Te mostrara un ENLACE y un CODIGO.
- Abre el enlace en tu navegador.
- Si no tienes cuenta, creala ahi mismo: la gratis alcanza.
- Pega el codigo y acepta, hasta que el navegador diga "Connected".
- La ventana te dira si quedo conectado.

ORDEN IMPORTANTE: tu cuenta se conecta EN TU SERVIDOR, no en tu
computadora. NO escribas comandos como "hermes ..." en tu propia
consola de Windows: ahi no existe Hermes y no conectarias nada.
Solo usa activar-nous.bat, que hace los dos pasos en orden: primero
entra a tu servidor y luego pide el inicio de sesion ahi dentro.

Tu contrasena de Nous no pasa por ningun lado.

## 4 REGLAS DE ORO (leelas antes de empezar)

L1. Todo pasa por los archivos .bat del ZIP. No escribas el
    comando interno en tu propia consola de Windows: ahi no
    existe Hermes y no conectarias nada.

L2. En tu servidor, el comando hermes vive en ~/.local/bin:
    si en una revision tecnica no se encuentra, se exporta
    esa ruta al PATH. activar-nous.ps1 ya lo hace solo.

L3. Que el navegador diga "Connected" no basta: la
    comprobacion de tu cuenta se hace EN el servidor, al
    final del PASO 5. Ah es donde se ve si quedo lista.

L4. La pagina web de tu agente no tiene inicio de sesion
    de Nous: el PASO 5 con activar-nous.bat es el unico
    camino valido.

## COMO USARLO TODOS LOS DIAS

- Doble clic en "conectar.bat" cada vez que quieras usarlo.
- Ya no pide contrasena, ni hay que repetir el PASO 5.
- Deja la VENTANA NEGRA MINIMIZADA abierta mientras trabajas:
  es el puente seguro. Si la cierras, se desconecta.
- Direcciones, por si las necesitas:
     Tu agente : http://127.0.0.1:8787
     Respaldo  : http://127.0.0.1:9119

## SEGURIDAD (IMPORTANTE)

- La conexion va cifrada. Nadie mas en internet puede entrar.
- Tu computadora NO queda expuesta: el servidor NO puede
  alcanzarla; solo tu alcanzas al servidor.
- Cierra la ventana negra cuando termines.
- Despues de tu primera conexion, CAMBIA la contrasena de tu
  servidor y guardala en un lugar seguro (pideselo a tu
  instructor o a tu propio agente).

## SI ALGO NO FUNCIONA

- El agente abre pero no contesta:
    Falta el PASO 5. Corre activar-nous.bat: el agente necesita
    tu cuenta de Nous conectada.
- La ventana se abre y se cierra sola:
    Asegurate de haber EXTRAIDO el ZIP y de estar corriendo
    conectar.bat desde la carpeta extraida. Si sigue igual,
    abre "conexion-log.txt" (queda junto a conectar.bat) y
    mandalo a tu instructor.
- "No encontre 'ssh'":
    Instala el cliente SSH -> Configuracion de Windows ->
    Sistema -> Caracteristicas opcionales -> Agregar una
    caracteristica -> "Cliente OpenSSH" -> Instalar.
- La pagina no carga:
    Revisa que la ventana negra siga abierta (minimizada).
- "Address already in use":
    Ya tienes otra ventana de conexion abierta. Cierra las
    demas y vuelve a intentar.
- Te pide contrasena y la rechaza:
    Copiala exactamente, sin espacios de mas. Reintenta.
- Nada de lo anterior: manda a tu instructor una captura de
  la ventana negra + el archivo conexion-log.txt.

## TU TAREA FINAL (opcional, del taller)

Crea un acceso directo en el Escritorio para que sea 1 clic:
   Clic derecho en "conectar.bat"
   -> "Enviar a" -> "Escritorio (crear acceso directo)".
