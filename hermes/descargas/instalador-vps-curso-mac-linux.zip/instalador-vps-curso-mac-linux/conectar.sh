#!/usr/bin/env bash
# ============================================================
#  SolarPunk MX — Lanzador de conexión (Linux y macOS)
#  Un clic: abre el túnel seguro a tu VPS y tu agente en el navegador.
#  No guarda contraseñas. No permite que el VPS alcance tu computadora.
# ============================================================
set -uo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# --- Leer config.txt (junto al script o en la carpeta padre) ---
CFG="$HERE/config.txt"
[ -f "$CFG" ] || CFG="$HERE/../config.txt"
if [ ! -f "$CFG" ]; then echo "ERROR: falta config.txt junto a este script."; exit 1; fi
VPS_HOST=""; VPS_USER="root"; SSH_PORT="22"; WEB_PORT="8787"; DASH_PORT="9119"
while IFS='=' read -r k v; do
  k="$(echo "$k" | tr -d '[:space:]')"; v="$(echo "$v" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')"
  case "$k" in
    VPS_HOST)  [ -n "$v" ] && VPS_HOST="$v" ;;
    VPS_USER)  [ -n "$v" ] && VPS_USER="$v" ;;
    SSH_PORT)  [ -n "$v" ] && SSH_PORT="$v" ;;
    WEB_PORT)  [ -n "$v" ] && WEB_PORT="$v" ;;
    DASH_PORT) [ -n "$v" ] && DASH_PORT="$v" ;;
  esac
done < <(grep -v '^[[:space:]]*#' "$CFG")

LOCAL_WEB="$WEB_PORT"; LOCAL_DASH="$DASH_PORT"
KEY="$HOME/.ssh/solarpunk_vps_ed25519"

abort(){ printf '\n%s\n' "$*"; printf 'Presiona Enter para cerrar…'; read -r _; exit 1; }

# --- Pedir la IP si no está puesta (ZIP genérico) ---
if [ -z "$VPS_HOST" ] || [ "$VPS_HOST" = "TU_IP_O_HOST" ]; then
  printf '\nEscribe la IP de tu servidor (la de tu panel de Contabo): '
  read -r VPS_HOST
  [ -n "$VPS_HOST" ] || abort "No escribiste ninguna IP."
  printf 'VPS_HOST=%s\n' "$VPS_HOST" >> "$CFG" 2>/dev/null || true
fi
command -v ssh >/dev/null 2>&1 || abort "No encontré 'ssh'. instálalo y vuelve a intentar."
command -v ssh-keygen >/dev/null 2>&1 || abort "No encontré 'ssh-keygen'."

SSH_OPTS=(-o StrictHostKeyChecking=accept-new -o ForwardAgent=no \
          -o ServerAliveInterval=30 -o ServerAliveCountMax=3 \
          -o ExitOnForwardFailure=yes -p "$SSH_PORT")

# --- 1. Generar la llave si no existe ---
gen_key(){
  mkdir -p "$(dirname "$KEY")"; chmod 700 "$(dirname "$KEY")"
  ssh-keygen -q -t ed25519 -f "$KEY" -N "" -C "solarpunk-$(hostname)" 2>/dev/null
  # Algunos builds cifran la llave aunque -N vaya vacío: detectarlo y reintentar.
  if grep -q "bcrypt" "$KEY" 2>/dev/null; then
    rm -f "$KEY" "$KEY.pub"
    echo "Cuando ssh-keygen pregunte, presiona Enter DOS veces sin escribir nada."
    ssh-keygen -t ed25519 -f "$KEY" -C "solarpunk-$(hostname)"
  fi
  grep -q "bcrypt" "$KEY" 2>/dev/null && abort "No se pudo crear la llave sin contraseña."
  return 0
}
if [ ! -f "$KEY" ]; then
  echo "Generando tu llave de acceso (una sola vez)…"
  gen_key
fi

# --- 2. Enrolar la llave (solo la primera vez) ---
if ! ssh -o BatchMode=yes -o ConnectTimeout=7 "${SSH_OPTS[@]}" -i "$KEY" "$VPS_USER@$VPS_HOST" true 2>/dev/null; then
  echo
  echo "Primera conexión a este servidor. Te pedirá la contraseña UNA vez."
  echo "(Es la contraseña inicial de tu VPS. Solo sirve para instalar tu llave.)"
  PUB="$(cat "$KEY.pub")"
  ssh "${SSH_OPTS[@]}" "$VPS_USER@$VPS_HOST" \
    "mkdir -p ~/.ssh && chmod 700 ~/.ssh && touch ~/.ssh/authorized_keys && chmod 600 ~/.ssh/authorized_keys && grep -qxF '$PUB' ~/.ssh/authorized_keys || echo '$PUB' >> ~/.ssh/authorized_keys" \
    || abort "No pude autenticar. Revisa la contraseña y vuelve a intentar."
  ssh -o BatchMode=yes -o ConnectTimeout=7 "${SSH_OPTS[@]}" -i "$KEY" "$VPS_USER@$VPS_HOST" true 2>/dev/null \
    || abort "La llave no quedó instalada. Vuelve a intentar."
  echo "Listo: tu llave quedó instalada. Ya no volverá a pedir contraseña."
fi

# --- 3. Abrir el navegador (en cuanto el túnel responda) ---
open_browser(){
  local url="$1"
  if command -v xdg-open >/dev/null 2>&1; then xdg-open "$url" >/dev/null 2>&1 &
  elif command -v open >/dev/null 2>&1; then open "$url" >/dev/null 2>&1 &
  else echo "Abre manualmente: $url"; fi
}

echo
echo "Abriendo túnel seguro al VPS…"
( for _ in $(seq 1 20); do
    if (exec 3<>"/dev/tcp/127.0.0.1/$LOCAL_WEB") 2>/dev/null; then exec 3>&-; break; fi
    sleep 0.5
  done ) &
sleep 2
open_browser "http://127.0.0.1:$LOCAL_WEB"
# El Dashboard es OTRA aplicación (config, claves, sesiones, cron, kanban).
if [ "$LOCAL_DASH" != "$LOCAL_WEB" ]; then
  for _ in $(seq 1 20); do
    if (exec 3<>"/dev/tcp/127.0.0.1/$LOCAL_DASH") 2>/dev/null; then exec 3>&-; break; fi
    sleep 0.5
  done
  open_browser "http://127.0.0.1:$LOCAL_DASH"
fi

echo "==============================================="
echo "  TU AGENTE ESTÁ ABIERTO EN EL NAVEGADOR"
echo "  Chat (agente) : http://127.0.0.1:$LOCAL_WEB"
echo "  Dashboard     : http://127.0.0.1:$LOCAL_DASH   (panel de control)"
echo "  Deja ESTA ventana abierta: es el puente seguro."
echo "  Ciérrala para desconectarte."
echo "==============================================="

# --- 4. Mantener el túnel vivo (reconexión automática) ---
port_free(){ ! (exec 3<>"/dev/tcp/127.0.0.1/$1") 2>/dev/null; }
FORWARDS=(-L "${LOCAL_WEB}:127.0.0.1:${WEB_PORT}")
if port_free "$LOCAL_DASH"; then
  FORWARDS+=(-L "${LOCAL_DASH}:127.0.0.1:${DASH_PORT}")
else
  echo "Nota: el puerto local $LOCAL_DASH ya estaba en uso; abro solo la interfaz principal."
fi

trap 'echo; echo "Cerrando túnel…"; exit 0' INT TERM
while true; do
  ssh -N "${SSH_OPTS[@]}" -i "$KEY" \
      "${FORWARDS[@]}" \
      "$VPS_USER@$VPS_HOST"
  echo "El túnel se cayó; reintentando en 3 s… (Ctrl+C para salir)"
  sleep 3
done
