# ============================================================
#  SolarPunk MX - Activar tu cuenta de Nous   (Windows 11)   v2
#
#  IMPORTANTE — el orden correcto:
#  Tu cuenta se conecta EN TU SERVIDOR, no en tu PC.
#  Este archivo hace los dos pasos por ti, en orden:
#     1) entra a tu servidor por SSH
#     2) ahi dentro pide el inicio de sesion
#  Nunca escribas el comando "hermes ..." en tu propia consola:
#  ahi no existe Hermes y se conectaria tu PC, no el servidor.
#
#  Usa la misma llave que ya instalo conectar.bat: NO pide contrasena.
#  No guarda nada en tu PC.
# ============================================================
$ErrorActionPreference = "Continue"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not $here) { $here = (Get-Location).Path }
$log  = Join-Path $here "activar-nous-log.txt"
function Say([string]$m) { Write-Host $m; Add-Content -Path $log -Value $m -ErrorAction SilentlyContinue }
function Pausa([string]$m) { if ($m) { Write-Host ""; Write-Host $m }; Write-Host ""; Write-Host "Presiona Enter para cerrar esta ventana..."; try { [void](Read-Host) } catch { Start-Sleep -Seconds 20 } }

Say "==============================================="
Say "  SolarPunk MX - activar tu cuenta de Nous"
Say "==============================================="

$cfg = Join-Path $here "config.txt"
if (-not (Test-Path $cfg)) { $cfg = Join-Path (Split-Path -Parent $here) "config.txt" }
if (-not (Test-Path $cfg)) { Pausa "ERROR: falta config.txt junto a este script."; exit 1 }

$conf = @{}
Get-Content $cfg | ForEach-Object {
  $line = $_.Trim()
  if ($line -eq "" -or $line.StartsWith("#")) { return }
  $i = $line.IndexOf("=")
  if ($i -gt 0) { $conf[$line.Substring(0,$i).Trim()] = $line.Substring($i+1).Trim() }
}
$VpsHost = $conf["VPS_HOST"]
$VpsUser = if ($conf["VPS_USER"]) { $conf["VPS_USER"] } else { "root" }
$SshPort = if ($conf["SSH_PORT"]) { $conf["SSH_PORT"] } else { "22" }

if (-not $VpsHost -or $VpsHost -eq "TU_IP_O_HOST") {
  Pausa "Primero corre conectar.bat (ahi se guarda la IP de tu servidor)."; exit 1
}

$key = Join-Path (Join-Path $env:USERPROFILE ".ssh") "solarpunk_vps_ed25519"
if (-not (Test-Path $key)) {
  Pausa "Todavia no tienes llave de acceso. Corre primero conectar.bat (te pedira la contrasena una vez)."; exit 1
}

Say "Servidor: $VpsUser@$VpsHost (SSH $SshPort)"
Say ""
Say "Este programa va a:"
Say "  1. Entrar a tu servidor."
Say "  2. Ahi dentro abrir el inicio de sesion de Nous."
Say ""
Say "Te va a mostrar un ENLACE con un CODIGO."
Say "Abre ese enlace en tu navegador y confirma. Tu contrasena de Nous"
Say "no pasa por esta ventana ni se guarda en tu PC."
Say ""

$common = @("-t","-o","StrictHostKeyChecking=accept-new","-o","ForwardAgent=no",
            "-o","ServerAliveInterval=30","-o","ServerAliveCountMax=3",
            "-o","IdentitiesOnly=yes","-p",$SshPort)

# En ssh no-interactivo el PATH no incluye ~/.local/bin: se exporta siempre.
$PRE = 'export PATH="$HOME/.local/bin:$PATH"; '

# 1. Iniciar sesion DENTRO del servidor
& ssh @common "-i" $key "$VpsUser@$VpsHost" "$PRE hermes auth add nous --type oauth --no-browser"

Say ""
Say "--- Comprobando el resultado en el servidor ---"
$chk = & ssh @common "-i" $key "$VpsUser@$VpsHost" "$PRE hermes portal info; echo; echo MODELO:; $PRE hermes config get model.default" 2>&1
$chk | ForEach-Object { Say $_ }

Say ""
if (($chk -join "`n") -match "logged in") {
  Say "LISTO: tu cuenta quedo conectada en el servidor."
  Pausa "Cierra esta ventana y usa conectar.bat para trabajar."
} else {
  Say "AUN NO queda conectada."
  Say "Corre de nuevo este archivo y completa el enlace hasta el final,"
  Say "hasta que el navegador diga 'Connected'."
  Pausa "Si se repite, manda activar-nous-log.txt a tu instructor."
}
