@echo off
REM ============================================================
REM  SolarPunk MX - Lanzador de conexion (Windows 11)   v4
REM  Doble clic aqui. El resto lo hace PowerShell.
REM  Si algo falla, esta ventana NO se cierra: muestra el error
REM  y deja un archivo conexion-log.txt junto a este script.
REM ============================================================
setlocal
set "AQUI=%~dp0"
cd /d "%AQUI%"

if not exist "conectar.ps1" if exist "windows\conectar.ps1" cd /d "%AQUI%windows"

if not exist "conectar.ps1" (
  echo.
  echo No encuentro conectar.ps1 en esta carpeta:
  echo   %CD%
  echo.
  echo Si abriste el archivo desde el ZIP, primero descomprimelo:
  echo clic derecho en el ZIP -^> "Extraer todo..." -^> y entra a la carpeta.
  echo.
  pause
  exit /b 1
)

echo.
echo  Iniciando conexion segura con tu agente SolarPunk...
echo.

REM Quita la marca de "archivo descargado" para que Windows no lo bloquee.
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -LiteralPath '%CD%' -Recurse -File -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue" >nul 2>&1

powershell -NoProfile -ExecutionPolicy Bypass -File "%CD%\conectar.ps1"
set "RC=%ERRORLEVEL%"

echo.
echo  ------------------------------------------------------------
if not "%RC%"=="0" echo  El lanzador termino con codigo %RC%.
if exist "conexion-log.txt" echo  Diagnostico guardado en: %CD%\conexion-log.txt
echo  ------------------------------------------------------------
pause
endlocal
