# Conecta tu computadora al VPS del curso (macOS y Linux)

Este paquete abre tu agente, que vive en **tu servidor**, desde el navegador
de tu computadora. No instalas Hermes en tu equipo: solo abres el túnel.

## Lo que necesitas a la mano

1. Tu computadora con macOS o Linux.
2. La IP de tu servidor.
3. La contraseña de tu servidor.
4. Tu cuenta de Nous Research (gratis).

## Paso 1. Rellena `config.txt`

Abre `config.txt` con cualquier editor de texto y pon tu IP en `VPS_HOST`.
Deja lo demás como está. No escribas contraseñas ahí.

## Paso 2. Abre la Terminal

- **macOS:** Cmd + Espacio, escribe `Terminal`, Enter.
- **Linux:** Ctrl + Alt + T en la mayoría de las distribuciones.

## Paso 3. Entra a la carpeta y ejecuta

```bash
cd ~/Descargas/instalador-vps-curso-mac-linux
bash conectar.sh
```

Si macOS te dice que no puede abrir el archivo porque viene de internet,
haz esto una vez:

```bash
xattr -d com.apple.quarantine conectar.sh
chmod +x conectar.sh
bash conectar.sh
```

## Paso 4. Deja la ventana abierta

El túnel vive mientras esa ventana esté abierta. El navegador se abre solo en
`http://127.0.0.1:8787`.

Para cerrar el túnel: Ctrl + C en la misma ventana.

## Paso 5. Activa tu cuenta de Nous Research

La primera vez, dentro de la interfaz, pide a tu agente que te guíe para
conectar tu cuenta. Si no tienes cuenta, se crea gratis en
`portal.nousresearch.com`.

## Si algo falla

El script te dice exactamente qué falló y deja el detalle en pantalla.
Lo más común:

- **No encuentra ssh:** instálalo (`sudo apt install openssh-client` en Linux;
  en macOS ya viene).
- **Contraseña incorrecta:** la de tu servidor, no la del Club.
- **Conexión rechazada:** revisa que la IP esté bien escrita en `config.txt`.

Pega el error a tu agente local y él te ayuda a resolverlo.
