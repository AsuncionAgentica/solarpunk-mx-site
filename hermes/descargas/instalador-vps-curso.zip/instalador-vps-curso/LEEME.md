# Instalador para el VPS del curso

Este paquete se usa **en el servidor**, no en tu computadora. Deja el agente
Hermes corriendo y te da la interfaz web para usarlo desde el navegador.

## Qué trae

| Archivo | Para qué |
|---|---|
| `preparar-vps.sh` | Instala Hermes si falta, monta la interfaz web y el panel, y los deja como servicios que arrancan solos. |
| `verificar-vps.sh` | Comprueba que los servicios estén arriba y respondan. |
| `abrir-interfaz.sh` | Lanzador: abre el túnel desde tu computadora y te deja la interfaz lista en el navegador. |
| `config.txt` | Tus datos del servidor. **Rellénalo antes de conectar.** |

## Orden

**1. Antes de conectar** — edita `config.txt` con la IP que te dio tu proveedor.
No pongas contraseñas ni llaves ahí: solo la IP, el usuario y los puertos.

**2. Instalar en el servidor.** Desde tu computadora:

```bash
scp preparar-vps.sh root@TU_IP:/root/
ssh root@TU_IP 'bash /root/preparar-vps.sh'
```

Toma entre 10 y 20 minutos si Hermes hay que instalarlo desde cero. Es
idempotente: si se corta, lo vuelves a correr y sigue donde iba.

**3. Comprobar.** Copia `verificar-vps.sh` igual que el anterior y córrelo:

```bash
scp verificar-vps.sh root@TU_IP:/root/
ssh root@TU_IP 'bash /root/verificar-vps.sh'
```

Debe reportar `hermes-webui` y `hermes-backend` activos.

**4. Abrir la interfaz** desde tu computadora, con el túnel:

```bash
bash abrir-interfaz.sh
```

Te abre el navegador en la interfaz. El túnel deja el servidor escuchando solo
en `127.0.0.1`: no queda expuesto a internet.

## Por qué se conecta por túnel y no se abre al mundo

El panel de Hermes puede ejecutar comandos en el servidor. Si se abre a internet
sin más, cualquiera que encuentre la IP y el puerto puede intentar entrar. El túnel
SSH lo deja accesible solo para ti, con la llave que ya tienes.

## Si algo falla

En el servidor:

```bash
systemctl status hermes-webui hermes-backend
journalctl -u hermes-webui -n 50 --no-pager
journalctl -u hermes-backend -n 50 --no-pager
```

Y pídele a tu agente local que te ayude: dale la salida de esos comandos y él
sabe repararlo desde adentro.

## Nunca hagas esto

- No montes tu carpeta `.hermes` local dentro de un contenedor en el servidor.
- No abras el puerto del panel a internet sin autenticación.
- No guardes contraseñas ni llaves dentro de este paquete.
